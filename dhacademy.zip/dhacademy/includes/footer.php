<!-- Global WhatsApp Floating Button -->
<?php
$whatsapp_number = '1234567890'; // Replace with actual number
$default_message = urlencode("Hello DH ACADEMY, I have an inquiry.");
?>
<a href="https://wa.me/<?= $whatsapp_number ?>?text=<?= $default_message ?>" class="whatsapp-float d-flex align-items-center justify-content-center" target="_blank" rel="noopener noreferrer">
    <i class="fab fa-whatsapp"></i>
</a>

<!-- Footer -->
<footer class="bg-primary-custom text-white pt-5 pb-4 mt-auto">
    <div class="container text-center text-md-start">
        <div class="row text-center text-md-start">
            
            <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                <h5 class="text-uppercase mb-4 fw-bold text-warning">DH ACADEMY</h5>
                <p>Empowering students across India with high-quality, affordable technical and non-technical skill courses.</p>
            </div>
            
            <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                <h5 class="text-uppercase mb-4 fw-bold">Quick Links</h5>
                <p><a href="<?= $base_url ?>courses.php" class="text-white text-decoration-none">All Courses</a></p>
                <p><a href="<?= $base_url ?>about.php" class="text-white text-decoration-none">About Us</a></p>
                <p><a href="<?= $base_url ?>contact.php" class="text-white text-decoration-none">Contact Us</a></p>
                <p><a href="<?= $base_url ?>login.php" class="text-white text-decoration-none">Student Login</a></p>
            </div>
            
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mt-3">
                <h5 class="text-uppercase mb-4 fw-bold">Contact</h5>
                <p><i class="fas fa-envelope mr-3"></i> support@dhacademy.com</p>
                <p><i class="fas fa-phone mr-3"></i> +91 98765 43210</p>
            </div>
            
        </div>
        
        <hr class="mb-4">
        
        <div class="row align-items-center">
            <div class="col-md-7 col-lg-8">
                <p>&copy; <?= date("Y") ?> All rights reserved by <strong>DH ACADEMY</strong>.</p>
            </div>
            <div class="col-md-5 col-lg-4">
                <div class="text-center text-md-end">
                    <ul class="list-unstyled list-inline">
                        <li class="list-inline-item"><a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-facebook"></i></a></li>
                        <li class="list-inline-item"><a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-twitter"></i></a></li>
                        <li class="list-inline-item"><a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-linkedin-in"></i></a></li>
                        <li class="list-inline-item"><a href="#" class="btn-floating btn-sm text-white" style="font-size: 23px;"><i class="fab fa-youtube"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
        
    </div>
</footer>
<!-- Footer -->

<!-- MDB -->
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
<!-- Main JS -->
<script src="<?= $base_url ?>assets/js/main.js"></script>
</body>
</html>
