<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$base_url = '/dhacademy/';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    // If it's an API call, return JSON
    if (strpos($_SERVER['REQUEST_URI'], '/api/') !== false) {
        header('Content-Type: application/json');
        echo json_encode(['status' => 'error', 'message' => 'Unauthorized Access']);
        exit;
    }
    
    // Otherwise redirect to login
    header("Location: " . $base_url . "login.php");
    exit;
}
?>
