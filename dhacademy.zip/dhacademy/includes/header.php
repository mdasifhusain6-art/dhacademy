<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
$base_url = '/dhacademy/'; // Adjust depending on your web root setup
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? htmlspecialchars($page_title) : 'DH ACADEMY | Online Learning Platform' ?></title>
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?= isset($page_description) ? htmlspecialchars($page_description) : 'DH ACADEMY offers top technical and non-technical skill courses.' ?>">
    <meta property="og:title" content="<?= isset($page_title) ? htmlspecialchars($page_title) : 'DH ACADEMY' ?>">
    <meta property="og:description" content="<?= isset($page_description) ? htmlspecialchars($page_description) : 'Join DH ACADEMY to upskill your career today.' ?>">
    <meta property="og:type" content="website">

    <!-- Fonts & Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <!-- MDB -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="<?= $base_url ?>assets/css/style.css">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-primary-custom sticky-top">
  <div class="container">
    <a class="navbar-brand fw-bold" href="<?= $base_url ?>index.php">
        <i class="fas fa-graduation-cap text-warning me-2"></i>DH ACADEMY
    </a>
    
    <button class="navbar-toggler" type="button" data-mdb-collapse-init data-mdb-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars"></i>
    </button>
    
    <div class="collapse navbar-collapse" id="mainNav">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?= $base_url ?>index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= $base_url ?>courses.php">Courses</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= $base_url ?>about.php">About</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="<?= $base_url ?>contact.php">Contact</a>
        </li>
      </ul>
      
      <div class="d-flex align-items-center">
        <?php if(!isset($_SESSION['user_id'])): ?>
            <a href="<?= $base_url ?>login.php" class="btn btn-outline-light btn-rounded me-2 px-4 shadow-0">Login</a>
            <a href="<?= $base_url ?>register.php" class="btn btn-action btn-rounded px-4 shadow-0">Sign Up</a>
        <?php else: ?>
            <span class="text-white me-3 d-none d-lg-block">Hello, <?= htmlspecialchars($_SESSION['name']) ?></span>
            <a href="<?= $base_url ?><?= $_SESSION['role'] === 'admin' ? 'admin/dashboard.php' : 'dashboard/index.php' ?>" class="btn btn-warning btn-rounded px-4 shadow-0 me-2">Dashboard</a>
            <a href="<?= $base_url ?>logout.php" class="btn btn-outline-light btn-sm btn-floating"><i class="fas fa-sign-out-alt"></i></a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<!-- Navbar -->
