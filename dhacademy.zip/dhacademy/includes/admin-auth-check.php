<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$base_url = '/dhacademy/';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header("Location: " . $base_url . "admin/index.php");
    exit;
}
?>
