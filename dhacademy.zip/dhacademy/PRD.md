# PRD.md – DH ACADEMY E-Learning Platform
**Version:** 2.0  
**Updated:** 2026-03-05  
**Type:** Product Requirements Document  
**Stack:** HTML5 + CSS3 + JavaScript + MDBootstrap 5 + PHP (Core) + MySQL  
**Status:** ✅ Ready for AI-Assisted Development (Cline / Cursor / Windsurf)

---

## 1. Project Overview

DH ACADEMY is a mobile-first online course selling platform designed to sell technical and non-technical skill-based courses to students across India. The platform enables students to browse a structured course catalog, purchase courses securely through Razorpay, and instantly access all learning materials from a protected personal dashboard. Course resources (videos, PDFs, eBooks, source code, templates) are hosted on Google Drive to minimize server costs while maintaining fast delivery.

The system automates the full student lifecycle: from course discovery and payment, to account creation, content access, and certificate issuance. A powerful admin panel gives the institute owner complete control over courses, students, orders, and analytics — all from a single interface.

**Core Philosophy:** Low infrastructure cost · High automation · High conversion · Mobile-first experience

**Business Goal:** Build a scalable digital education platform that sells skill courses, issues certificates, and grows revenue through multiple streams while keeping operational overhead minimal.

---

## 2. Technology Stack

| Layer              | Technology                              |
|--------------------|------------------------------------------|
| Frontend           | HTML5, CSS3, JavaScript, MDBootstrap 5  |
| Backend            | PHP (Core PHP — no framework)           |
| Database           | MySQL 8.x                               |
| Payment Gateway    | Razorpay API (Orders + Webhooks)        |
| Content Hosting    | Google Drive (View-only embedded links) |
| SEO                | Meta tags, Open Graph, Schema.org JSON-LD |
| Dev Environment    | VS Code / XAMPP (Apache + MySQL)        |
| Version Control    | Git + GitHub                            |
| Deployment         | cPanel Shared Hosting / VPS             |

---

## 3. Structured Feature Set

### 3.1 Student Account System

#### Registration
- Register form fields: Full Name, Email, Phone, Password, Confirm Password
- Phone number format validation (Indian 10-digit)
- Email uniqueness check (AJAX real-time)
- Password minimum 8 characters with strength indicator
- On successful registration → redirect to dashboard or last visited course

#### Login
- Login via Email + Password
- "Remember Me" checkbox (persistent session cookie, 30 days)
- Forgot password flow: email OTP or reset link (Phase 2)
- Incorrect password → show error (do not reveal which field is wrong)
- Brute-force protection: lock after 5 failed attempts (15-min cooldown)
- Redirect to intended page after login (not always dashboard)

#### Student Profile
- Profile page: view and edit Name, Phone, Profile Photo
- Change password form (current password required)
- Enrolled courses count badge
- Certificates earned count badge
- Account created date display
- WhatsApp-linked phone number display

#### Student Dashboard
- Personalized greeting: "Welcome back, [Name] 👋"
- Summary cards: Courses Enrolled, Certificates Earned, Resources Available
- "My Courses" section with course thumbnails and access buttons
- Recent activity (last accessed course)
- WhatsApp Support floating button (all pages)
- Certificate Request button per completed course
- Quick links: Browse More Courses, Contact Support, Download Resources

---

### 3.2 Course Catalog

#### Catalog Page (`courses.html`)
- Display all active courses in a responsive card grid (2 columns mobile, 3 desktop)
- Filter sidebar / top filter bar:
  - Filter by Category (Technical / Non-Technical / All)
  - Filter by Price (Free / Paid / Under ₹500 / Under ₹1000)
  - Filter by Duration (Short / Medium / Long)
  - Sort by: Newest / Price Low-High / Price High-Low / Most Popular
- Search bar with real-time filter (JavaScript-based, no page reload)
- Course count display: "Showing 12 of 18 courses"
- Lazy loading for course images
- "No results found" empty state with CTA to browse all

#### Course Card Components
Each course card must display:
- Course thumbnail image (16:9 ratio)
- Category badge (color-coded by category)
- Course name (max 2 lines, truncate with ellipsis)
- Short description (max 2 lines)
- Duration badge (e.g., "3 Months")
- Certificate badge (🏆 Certificate Included)
- Original price + Discounted price (strikethrough on original)
- Discount % badge (e.g., "30% OFF") — shown only if discount exists
- ⭐ Average rating (1 decimal, e.g., 4.7) + review count
- "View Details" button → links to course detail page
- "Buy Now" shortcut button (opens Razorpay directly)
- Hover effect: card lift shadow + CTA highlight

#### Course Categories Display
- Category grid on homepage and catalog page
- Each category: icon + name + course count
- Clickable → filters catalog to that category

**Technical Courses:**
- ADCA (Advanced Diploma in Computer Applications)
- DCA (Diploma in Computer Applications)
- Tally (Accounting Software)
- Web Development
- App Development (Flutter)
- Full Stack Development
- PHP Development

**Non-Technical Courses:**
- Diploma in Nursery Teacher Training (DNTT)
- Advanced Nursery Teacher Training
- Digital Marketing
- Advanced Digital Marketing
- Fire and Safety Management

---

### 3.3 Course Detail Page (`course-details.php?id=X`)

The course detail page is the primary conversion page. Every element must build trust and drive the Buy Now action.

#### Page Sections (Top to Bottom)
1. **Breadcrumb** — Home > Courses > [Category] > [Course Name]
2. **Course Header Block**
   - Course title (H1)
   - Short tagline / subtitle
   - ⭐ Rating + review count
   - Category badge
   - Last updated date
   - Instructor name + avatar
3. **Preview Media Block**
   - Course thumbnail or YouTube preview embed (autoplay muted)
   - On mobile: stacks above the purchase box
4. **Purchase Box (Sticky on Desktop, Fixed Bottom Bar on Mobile)**
   - Course price (large, bold)
   - Original price with strikethrough (if discounted)
   - Discount % badge
   - Offer countdown timer (if active offer)
   - ✅ Certificate Included badge
   - ✅ Lifetime Access badge
   - ✅ Google Drive Materials badge
   - **"Buy Now" button** (primary CTA — triggers Razorpay)
   - WhatsApp Enquiry link
5. **Course Description** — Full HTML text, formatted
6. **What You Will Learn** — Bullet point grid (2 columns)
7. **Course Syllabus** — MDBAccordion (Module > Topics list)
8. **Course Details Table** — Duration, Language, Certificate, Mode, Level
9. **Instructor Section** — Name, photo, short bio
10. **Student Reviews Section** — Avg rating + star bars + review cards + "Write a Review"
11. **Related Courses** — 3 cards from same category
12. **FAQ Section** — MDBAccordion of common questions

---

### 3.4 Razorpay Payment Integration

#### Pre-Payment Logic
- "Buy Now" button checks login status
  - If not logged in → show login modal with redirect back to course after login
  - If already purchased → show "Go to Dashboard" instead of "Buy Now"
  - If logged in but not purchased → proceed to payment

#### Payment Initiation
- Frontend calls `api/create-order.php` with `course_id`
- Backend creates Razorpay Order via Razorpay Orders API
- Returns `razorpay_order_id`, `amount`, `currency`
- Frontend opens Razorpay Checkout popup with pre-filled name, email, phone from student profile

#### Backend Verification (`payment-verify.php`)
```
Receive: payment_id + order_id + signature
        ↓
Generate expected signature:
HMAC_SHA256(order_id + "|" + payment_id, razorpay_key_secret)
        ↓
Compare with received signature
        ↓
If MATCH:
  → Insert into orders table (status = 'success')
  → If new user: create account (auto email + hashed password)
  → Grant course access
  → Return JSON: { status: "success", redirect: "/dashboard/" }
        ↓
If NO MATCH:
  → Insert into orders table (status = 'failed')
  → Return JSON: { status: "failed", message: "Payment verification failed" }
```

#### Post-Payment
- Success → redirect to `dashboard/` with success toast notification
- Failure → redirect back to course page with error message
- Duplicate payment check: if `razorpay_order_id` already in DB → skip insert, grant access

#### Auto Account Creation (New Students)
- Triggered only if email does not exist in `users` table
- Generate temporary password (8-char alphanumeric)
- Hash with `password_hash()` (BCRYPT)
- Insert user record
- Display credentials on success page with "Change Password" prompt

---

### 3.5 Student Dashboard (Protected Area)

All dashboard pages require valid student session. Redirect to login if session absent.

#### Dashboard Home (`dashboard/index.php`)
- Header: student avatar, name, email
- Stats row: [Courses Enrolled] [Certificates] [Resources]
- **My Courses Section:**
  - Grid of enrolled course cards
  - Each card: thumbnail, course name, "Access Material" button, "Request Certificate" button
  - Empty state with "Browse Courses" CTA if no courses
- **Quick Actions Panel:** Browse Courses · WhatsApp Support · Download Resources · Request Certificate
- Recent activity (last accessed course)
- WhatsApp floating button (bottom-right, all pages)

#### My Courses (`dashboard/my-courses.php`)
- Full list of all purchased courses
- Each course: thumbnail, name, category, purchase date, access button
- "Access Study Material" → opens secure Google Drive link in new tab
- Access control: PHP checks `orders` table before serving Drive link
- If course not purchased and URL is guessed → redirect to login

#### Study Material Access Security
- Google Drive links are **never** in frontend HTML source
- Drive link fetched via PHP only after verifying `user_id` owns `course_id` in `orders` table
- PHP serves the link as a redirect: `header("Location: $drive_link")`
- Direct URL to `course-access.php` without valid session → 403 redirect

#### Resource Downloads
- PDF, eBook, template links listed per course
- Download links served through PHP auth check
- File served via Google Drive direct download link (auth-gated)

#### WhatsApp Support Button
- Floating fixed button (bottom-right, 56×56px, high z-index, all pages)
- Pre-filled message includes student name dynamically

#### Certificate Request
- "Request Certificate" button on each enrolled course card
- On click → opens WhatsApp with pre-filled message:
  `"Hello DH ACADEMY, I have completed [Course Name]. My Name: [Student Name], Email: [Email], Phone: [Phone]. Please issue my certificate."`
- Admin receives on WhatsApp → verifies → issues certificate
- Certificate link stored in `certificates` table by admin
- Student can view/download certificate from `dashboard/certificates.php`

---

### 3.6 Admin Panel (Protected — Admin Role Only)

Admin panel is completely separate from student area. Accessible at `/admin/`. Admin session checked on every admin page.

#### Admin Dashboard (`admin/dashboard.php`)
- Summary stat cards: Total Students · Total Courses · Total Orders · Revenue This Month · Pending Certificates
- Recent Orders table (last 10): student name, course, amount, date, status
- Recent Registrations table (last 10): name, email, phone, date
- Quick action buttons: Add Course · View Students · View Orders

#### Course Management

**Add Course (`admin/add-course.php`) — Form Fields:**
```
Course Name             → text (required)
Course Slug             → auto-generated, editable
Course Price            → number in ₹ (required)
Original Price          → number (for strikethrough)
Discount %              → auto-calculated or manual
Course Image            → file upload → /assets/images/courses/
Course Category         → dropdown (Technical / Non-Technical + subcategory)
Short Description       → textarea (max 200 chars)
Full Description        → textarea (HTML allowed)
Syllabus                → repeatable: Module Name + Topics (comma-separated)
What You Will Learn     → repeatable bullet points
Course Duration         → text (e.g. "3 Months", "45 Hours")
Course Level            → dropdown (Beginner / Intermediate / Advanced)
Course Language         → dropdown (Hindi / English / Hinglish)
Certificate Available   → radio (Yes / No)
Google Drive Link       → URL (never exposed to students)
Course Mode             → dropdown (Online / Offline / Hybrid)
Instructor Name         → text
Instructor Bio          → textarea
Offer Active            → toggle (Yes / No)
Offer End Date          → date-time picker
Offer Label             → text (e.g. "Launch Offer")
SEO Title               → text (pre-filled from course name)
SEO Description         → textarea (max 160 chars)
Status                  → toggle (Active / Inactive)
```

**Manage Courses (`admin/manage-courses.php`):**
- Paginated table: ID, Image, Name, Category, Price, Status, Actions
- Actions: Edit | Delete | Toggle Active/Inactive | Preview
- Search/filter by name or category
- Bulk delete option

**Edit Course:** Same form, pre-filled. Confirmation dialog before saving.

#### Student Management (`admin/manage-students.php`)
- Paginated table: ID, Name, Email, Phone, Enrolled Courses Count, Registered Date
- Click student row → view student detail (courses purchased, certificates)
- Search by name, email, or phone
- Export to CSV

#### Order & Payment Management (`admin/manage-orders.php`)
- Paginated table: Order ID, Student Name, Course Name, Amount, Razorpay Payment ID, Status, Date
- Filter by: payment status, date range, course
- Revenue summary: Today / This Week / This Month / All Time
- Export to CSV

#### Certificate Management (`admin/manage-certificates.php`)
- View all certificate requests (from WhatsApp tracking)
- Manually add certificate: select student + course + upload certificate link
- View all issued certificates
- Mark certificate as issued / pending

#### Sales Analytics (`admin/analytics.php`)
- Revenue chart: daily / weekly / monthly (Chart.js bar/line)
- Top selling courses (ranked list)
- New students per month (bar chart)
- Total revenue lifetime counter
- Course-wise revenue breakdown table

---

### 3.7 Course Access Control

| User State                           | Behavior                                           |
|--------------------------------------|----------------------------------------------------|
| Not logged in, clicks Buy Now        | Login modal → redirect back to course after login  |
| Logged in, course not purchased      | Show Buy Now + Razorpay flow                       |
| Logged in, course already purchased  | Show "Go to Dashboard" + "Access Material"         |
| Direct URL to Drive link             | 403 — redirect to login                            |
| Admin accessing student dashboard    | 403 — admin has separate panel                     |
| Student accessing admin panel        | 403 — redirect to student dashboard                |
| API endpoint called without session  | 401 JSON error response                            |

---

### 3.8 Student Reviews System

#### Submitting a Review
- Review form on course detail page (visible only to students who purchased the course)
- Fields: Star rating (1–5 stars), Review title, Review text
- One review per student per course (update allowed)
- Stored in `reviews` table, linked to `user_id` + `course_id`
- Display name: first name + last initial (e.g., "Rahul K.")

#### Displaying Reviews
- Average rating calculated from `reviews` table, shown on course card + detail page
- Star breakdown bar chart (5★ to 1★ with percentage fill bars)
- Individual review cards: avatar initial, name, stars, date, comment
- "Load More" after 5 reviews
- Most recent reviews first
- Section hidden if zero reviews

#### Admin Review Moderation
- Admin can view all reviews in admin panel
- Toggle hide/show individual reviews
- Hidden reviews not displayed on frontend

---

### 3.9 Discount & Offer Display System

#### Offer Fields (in `courses` table)
- `original_price` — full price before discount
- `discount_price` — selling price
- `discount_percentage` — auto-calculated
- `offer_active` — ENUM('yes','no')
- `offer_end_date` — DATETIME (for countdown timer)
- `offer_label` — text (e.g. "Launch Offer", "Limited Time")

#### Display Rules
- If `offer_active = 'yes'` AND `offer_end_date > NOW()`:
  - Show strikethrough original price
  - Show discounted price in bold
  - Show discount % badge on course card
  - Show JavaScript countdown timer on course detail page
  - Show offer label banner on card
- If `offer_end_date <= NOW()` → PHP auto-hides offer, shows original price
- Homepage "Offer Banner" section highlights top 3 active offers

---

### 3.10 SEO & Performance

#### On-Page SEO (Every Page)
- Unique `<title>` tag: "Course Name | DH ACADEMY"
- Meta description per page (max 160 chars, dynamic on course pages)
- Open Graph tags for WhatsApp/Facebook share preview: `og:title`, `og:description`, `og:image`, `og:url`
- Canonical URL tags
- Semantic HTML: proper H1 > H2 > H3 hierarchy, `<main>`, `<article>`, `<section>`
- Alt text on all images
- Course detail pages: Schema.org `Course` JSON-LD structured data

#### Course Page Schema (JSON-LD)
```json
{
  "@context": "https://schema.org",
  "@type": "Course",
  "name": "[Course Name]",
  "description": "[Course Description]",
  "provider": {
    "@type": "Organization",
    "name": "DH ACADEMY"
  },
  "offers": {
    "@type": "Offer",
    "price": "[Price]",
    "priceCurrency": "INR"
  }
}
```

#### Performance
- Course images: WebP format, max 800px wide, compressed
- CSS/JS: minified in production
- MDBootstrap loaded from CDN
- Lazy load images below the fold (`loading="lazy"`)
- Google Fonts: preconnect + `display=swap`
- Browser caching headers via `.htaccess`

#### SEO URL Structure
| Page             | URL Pattern                                   |
|------------------|-----------------------------------------------|
| Homepage         | `/`                                           |
| Courses          | `/courses.html`                               |
| Course Detail    | `/course-details.php?id=X&slug=course-name`   |
| Student Dashboard| `/dashboard/`                                 |
| Admin Dashboard  | `/admin/`                                     |

---

### 3.11 Mobile-First Responsive Design (MDBootstrap 5)

#### Breakpoints
| Breakpoint   | Width     | Layout                                          |
|--------------|-----------|-------------------------------------------------|
| xs (mobile)  | < 576px   | Single column, stacked layout                   |
| sm           | ≥ 576px   | 2-column course grid                            |
| md (tablet)  | ≥ 768px   | 2-column + sidebar                              |
| lg (desktop) | ≥ 992px   | 3-column course grid, sidebar always visible    |
| xl           | ≥ 1200px  | Max-width container, centered                   |

#### Mobile-Specific Requirements
- Sticky "Buy Now" bar fixed at bottom of screen on course detail page (mobile only)
- Hamburger navigation with animated slide-in drawer
- Touch-friendly tap targets (minimum 44×44px)
- No horizontal scroll on any page at any breakpoint
- Course card swipe carousel on mobile homepage
- WhatsApp button: fixed bottom-right, 56×56px, z-index: 9999
- Dashboard stats: horizontally scrollable row on mobile

#### MDBootstrap Components to Use
- `MDBNavbar` + `MDBCollapse` — top navigation
- `MDBCard` — course cards
- `MDBCarousel` — testimonial + course slider
- `MDBAccordion` — syllabus + FAQ
- `MDBModal` — login prompt, confirmation dialogs
- `MDBToast` — success/error notifications
- `MDBBadge` — category, certificate, discount labels
- `MDBSpinner` — loading states during payment
- `MDBFooter` — site footer

---

## 4. Website Pages (Complete List)

### Public Pages
| File                    | Description                                       | SEO Priority |
|-------------------------|---------------------------------------------------|--------------|
| `index.html`            | Homepage — hero, courses, categories, reviews     | HIGH         |
| `courses.html`          | Full course catalog with search + filter          | HIGH         |
| `course-details.php`    | Dynamic individual course page                    | HIGHEST      |
| `login.php`             | Student login                                     | LOW          |
| `register.php`          | Student registration                              | LOW          |
| `about.html`            | About DH ACADEMY                                  | MEDIUM       |
| `contact.html`          | Contact form + WhatsApp link                      | MEDIUM       |

### Protected Student Pages
| File                           | Description                            |
|--------------------------------|----------------------------------------|
| `dashboard/index.php`          | Student dashboard home                 |
| `dashboard/my-courses.php`     | All purchased courses + access links   |
| `dashboard/profile.php`        | View + edit student profile            |
| `dashboard/certificates.php`   | View + download issued certificates    |

### Admin Pages
| File                                  | Description                       |
|---------------------------------------|-----------------------------------|
| `admin/index.php`                     | Admin login                       |
| `admin/dashboard.php`                 | Stats overview + recent activity  |
| `admin/add-course.php`                | Add new course form               |
| `admin/edit-course.php`               | Edit course form                  |
| `admin/manage-courses.php`            | Course list: edit/delete/toggle   |
| `admin/manage-students.php`           | All students                      |
| `admin/manage-orders.php`             | All orders + payments             |
| `admin/manage-certificates.php`       | Issue + track certificates        |
| `admin/analytics.php`                 | Revenue + enrollment charts       |

---

## 5. Database Schema (MySQL — Complete)

### `users`
```sql
CREATE TABLE users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(150) UNIQUE NOT NULL,
  phone         VARCHAR(15),
  password      VARCHAR(255) NOT NULL,
  profile_photo VARCHAR(255) DEFAULT NULL,
  role          ENUM('student', 'admin') DEFAULT 'student',
  is_active     TINYINT(1) DEFAULT 1,
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### `courses`
```sql
CREATE TABLE courses (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  course_name           VARCHAR(200) NOT NULL,
  course_slug           VARCHAR(200) UNIQUE NOT NULL,
  course_price          DECIMAL(10,2) NOT NULL,
  original_price        DECIMAL(10,2) DEFAULT NULL,
  discount_percentage   INT DEFAULT 0,
  course_image          VARCHAR(255),
  course_category       VARCHAR(100),
  course_subcategory    VARCHAR(100),
  short_description     VARCHAR(300),
  course_description    TEXT,
  syllabus              JSON,
  what_you_learn        TEXT,
  course_duration       VARCHAR(50),
  course_level          ENUM('Beginner','Intermediate','Advanced') DEFAULT 'Beginner',
  course_language       VARCHAR(50) DEFAULT 'Hindi',
  google_drive_link     VARCHAR(500),
  certificate_available ENUM('yes','no') DEFAULT 'yes',
  course_mode           ENUM('Online','Offline','Hybrid') DEFAULT 'Online',
  instructor_name       VARCHAR(100),
  instructor_bio        TEXT,
  offer_active          ENUM('yes','no') DEFAULT 'no',
  offer_end_date        DATETIME DEFAULT NULL,
  offer_label           VARCHAR(100) DEFAULT NULL,
  seo_title             VARCHAR(200),
  seo_description       VARCHAR(300),
  is_active             ENUM('yes','no') DEFAULT 'yes',
  created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### `orders`
```sql
CREATE TABLE orders (
  id                    INT AUTO_INCREMENT PRIMARY KEY,
  user_id               INT NOT NULL,
  course_id             INT NOT NULL,
  razorpay_order_id     VARCHAR(200) UNIQUE,
  razorpay_payment_id   VARCHAR(200),
  amount                DECIMAL(10,2) NOT NULL,
  payment_status        ENUM('pending','success','failed') DEFAULT 'pending',
  created_at            TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
```

### `certificates`
```sql
CREATE TABLE certificates (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  user_id          INT NOT NULL,
  course_id        INT NOT NULL,
  certificate_link VARCHAR(500),
  issue_date       DATE,
  status           ENUM('pending','issued') DEFAULT 'pending',
  created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id)
);
```

### `reviews`
```sql
CREATE TABLE reviews (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  course_id   INT NOT NULL,
  rating      TINYINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  title       VARCHAR(200),
  review_text TEXT,
  is_visible  TINYINT(1) DEFAULT 1,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id),
  FOREIGN KEY (course_id) REFERENCES courses(id),
  UNIQUE KEY unique_review (user_id, course_id)
);
```

---

## 6. Complete Folder Structure

```
dhacademy/
│
├── index.html                         ← Homepage (SEO optimized)
├── courses.html                       ← Course catalog
├── course-details.php                 ← Dynamic course page
├── about.html
├── contact.html
├── login.php
├── register.php
├── logout.php
├── .htaccess                          ← URL rewrite + security headers
│
├── dashboard/
│   ├── index.php                      ← Dashboard home
│   ├── my-courses.php                 ← Enrolled courses + access
│   ├── profile.php                    ← Student profile edit
│   └── certificates.php              ← View issued certificates
│
├── admin/
│   ├── index.php                      ← Admin login
│   ├── dashboard.php                  ← Stats + recent activity
│   ├── add-course.php                 ← Add course form
│   ├── edit-course.php                ← Edit course form
│   ├── manage-courses.php             ← Course list + actions
│   ├── manage-students.php            ← Students list
│   ├── manage-orders.php              ← Orders + payments
│   ├── manage-certificates.php        ← Certificate management
│   └── analytics.php                  ← Revenue + charts
│
├── api/
│   ├── create-order.php               ← Razorpay order creation
│   ├── payment-verify.php             ← HMAC SHA256 verify
│   ├── create-user.php                ← Auto account creation
│   ├── course-access.php              ← Serve Drive link after auth
│   ├── submit-review.php              ← Save student review
│   └── check-email.php               ← AJAX email uniqueness check
│
├── includes/
│   ├── header.php                     ← Common HTML head + navbar
│   ├── footer.php                     ← Common footer + WhatsApp button
│   ├── auth-check.php                 ← Session guard: student pages
│   └── admin-auth-check.php          ← Session guard: admin pages
│
├── assets/
│   ├── css/
│   │   ├── style.css                  ← Custom styles
│   │   └── admin.css                  ← Admin panel styles
│   ├── js/
│   │   ├── main.js                    ← Global JS
│   │   ├── payment.js                 ← Razorpay integration
│   │   ├── catalog-filter.js          ← Course search + filter
│   │   └── countdown.js               ← Offer countdown timer
│   └── images/
│       ├── courses/                   ← Course thumbnails
│       ├── instructors/               ← Instructor photos
│       └── logo.png
│
└── config/
    ├── database.php                   ← PDO DB connection
    └── razorpay.php                   ← API keys (gitignored)
```

---

## 7. Student User Flow

```
Visitor opens website (index.html)
        ↓
Browse / Search / Filter courses (courses.html)
        ↓
Open Course Detail Page (course-details.php)
        ↓
Read description, syllabus, reviews
        ↓
Click "Buy Now"
        ↓
[Not logged in] → Login modal → return to course
[Already purchased] → "Go to Dashboard"
[Logged in, not purchased] → proceed to payment
        ↓
Razorpay checkout opens (pre-filled details)
        ↓
Student pays (UPI / Card / Netbanking / Wallet)
        ↓
Razorpay returns payment_id + order_id + signature
        ↓
Backend verifies HMAC SHA256 signature
        ↓
Order inserted (status = 'success')
        ↓
[New user] Auto account created → credentials shown on screen
        ↓
Course access granted in orders table
        ↓
Redirect to Dashboard with success toast
        ↓
Student sees "My Courses" with new course
        ↓
Click "Access Study Material"
        ↓
PHP checks orders table → serves Drive link as redirect
        ↓
Google Drive course folder opens (view-only, new tab)
        ↓
Course completed → Click "Request Certificate"
        ↓
Pre-filled WhatsApp message opens to admin
        ↓
Admin verifies → issues certificate → stored in DB
        ↓
Certificate available in dashboard/certificates.php
```

---

## 8. Payment Flow (Razorpay — Detailed)

```
[Frontend] Buy Now clicked
        ↓
POST api/create-order.php { course_id }
        ↓
[Backend] Fetch course price from DB
        ↓
Razorpay::createOrder({ amount (paise), currency:"INR", receipt })
        ↓
Return { razorpay_order_id, amount, key_id }
        ↓
[Frontend] Open Razorpay Checkout popup
        ↓
Student completes payment
        ↓
[Razorpay] Returns: { razorpay_payment_id, razorpay_order_id, razorpay_signature }
        ↓
POST api/payment-verify.php { all three values + course_id }
        ↓
[Backend] HMAC_SHA256(order_id + "|" + payment_id, secret_key)
        ↓
VERIFIED:
  → INSERT orders (status='success')
  → Check if user exists → if not: INSERT users (auto-create)
  → Return { status:"ok", redirect:"/dashboard/" }
        ↓
NOT VERIFIED:
  → INSERT orders (status='failed')
  → Return { status:"error", message:"Payment verification failed" }
        ↓
[Frontend] "ok" → window.location = dashboard URL
[Frontend] "error" → show MDBToast error message
```

---

## 9. Security Requirements (Complete)

| Threat                       | Mitigation                                               |
|------------------------------|----------------------------------------------------------|
| SQL Injection                | PDO prepared statements on all queries                   |
| XSS                          | `htmlspecialchars()` on all user-generated output        |
| CSRF                         | CSRF tokens on all POST forms                            |
| Password storage             | `password_hash(BCRYPT)` + `password_verify()`            |
| Session hijacking            | `session_regenerate_id(true)` on every login             |
| Session timeout              | 2-hour inactivity auto-logout                            |
| Brute force login            | Lock after 5 failed attempts, 15-minute cooldown         |
| Payment tampering            | HMAC SHA256 Razorpay signature verification              |
| Direct course link access    | Drive links never in HTML; PHP serves only after auth    |
| Admin panel access           | Separate session + role='admin' check on every page      |
| Unauthorized API calls       | Session check in every API endpoint before processing    |
| Directory listing            | `Options -Indexes` in `.htaccess`                        |
| Config file exposure         | `config/` folder blocked in `.htaccess`                  |

---

## 10. Automation & Notifications

| Trigger                      | Automated Action                                         |
|------------------------------|----------------------------------------------------------|
| Payment success              | Order inserted + course access granted automatically     |
| New student auto-created     | Credentials shown on success page                        |
| Course purchased             | Dashboard immediately shows new course (no delay)        |
| Certificate requested        | Pre-filled WhatsApp message auto-opens to admin          |
| Offer end date reached       | Offer auto-hides (PHP `NOW()` check at render time)      |

---

## 11. Homepage Structure

| # | Section              | Content                                           | Notes                         |
|---|----------------------|---------------------------------------------------|-------------------------------|
| 1 | Hero                 | Headline + Subtitle + "Explore Courses" CTA       | Gradient background           |
| 2 | Stats Bar            | Students · Courses · Certificates (animated count)| Trust signal                  |
| 3 | Popular Courses      | Top 6 course cards grid (from DB)                 | Dynamic, show offers          |
| 4 | Categories           | Icon grid with course count per category          | Links to filtered catalog     |
| 5 | How It Works         | 3-step: Buy → Access → Get Certified              | Icons + short descriptions    |
| 6 | Student Reviews      | Testimonial carousel (MDBCarousel)                | 3–5 reviews                   |
| 7 | Certificate Section  | Badge image + benefits list                       | Trust-building section        |
| 8 | Offer Banner         | Active offer + countdown timer                    | Hidden if no active offer     |
| 9 | Call to Action       | "Start Learning Today" + enroll button            | Contrasting background color  |
| 10| Footer               | Links + social + WhatsApp + copyright             | Full-width                    |

---

## 12. Revenue Model

| Revenue Source         | Mechanism                                              | Price Range          |
|------------------------|--------------------------------------------------------|----------------------|
| Course Sales           | Direct Razorpay purchase                               | ₹299 – ₹2999         |
| Digital Bundles        | Course + eBook + Templates + Source Code               | ₹199 / ₹499 / ₹1499  |
| Certification Fees     | Certificate issued separately or bundled               | ₹299 – ₹999          |
| Affiliate Income       | Hopeway India affiliate links in course pages          | Commission-based     |
| Institute Admission    | Offline / hybrid admissions via contact form           | Custom               |

---

## 13. Future Enhancements (Phase 2+)

- [ ] Flutter mobile app (Android + iOS) — login, video player, course progress, certificate download
- [ ] Online quiz / exam system with auto-grading
- [ ] Auto PDF certificate generator (FPDF / TCPDF library)
- [ ] Video streaming player (replace Google Drive embeds)
- [ ] AI chatbot for course queries (fees, duration, enrollment)
- [ ] Student course progress tracking (% complete per module)
- [ ] Affiliate referral system with referral codes
- [ ] Push notifications (web + app)
- [ ] Coupon / promo code system at checkout
- [ ] Multi-instructor support
- [ ] LMS upgrade: assignments, live classes, discussion forums

---

## 14. Development Milestones

| Phase | Tasks                                                               | Priority |
|-------|---------------------------------------------------------------------|----------|
| 1     | DB setup, config files, folder structure, `.htaccess` rules         | HIGH     |
| 2     | Homepage (all 10 sections) + SEO meta tags                          | HIGH     |
| 3     | Course catalog + search/filter + course cards                       | HIGH     |
| 4     | Course detail page (full layout + syllabus accordion + reviews)     | HIGH     |
| 5     | Student register + login + session + profile page                   | HIGH     |
| 6     | Razorpay integration (create order + HMAC verify + auto account)    | HIGH     |
| 7     | Student dashboard + my courses + Drive access control               | HIGH     |
| 8     | Admin panel (courses, students, orders, certificates, analytics)    | HIGH     |
| 9     | Reviews system (submit + display + admin moderation)                | MEDIUM   |
| 10    | Discount/offer system + countdown timer display                     | MEDIUM   |
| 11    | Sales analytics dashboard (Chart.js charts)                         | MEDIUM   |
| 12    | SEO optimization (schema, OG tags, performance)                     | MEDIUM   |
| 13    | Security hardening (CSRF tokens, brute-force, header rules)         | HIGH     |
| 14    | Mobile responsiveness QA across all breakpoints                     | HIGH     |
| 15    | Full testing: payments, access control, admin, edge cases           | HIGH     |
| 16    | Deployment to cPanel / VPS + SSL + domain configuration             | HIGH     |

---

## 15. Complete Ecosystem Flow

```
YouTube / Social Media / Google Ads
            ↓
SEO-Optimized Website Traffic
            ↓
Course Catalog → Course Detail Page
            ↓
Buy Now → Razorpay Payment
            ↓
Auto Account Created → Course Access Granted
            ↓
Student Dashboard → Study Materials (Google Drive)
            ↓
Course Completed → Certificate Requested via WhatsApp
            ↓
Certificate Issued → Student Downloads + Shares
            ↓
Word of Mouth / Referrals → New Students
            ↓
                🔁 Repeat Loop
```

---

*PRD.md – DH ACADEMY | Version 2.0 | Updated 2026-03-05*  
*Ready for AI-assisted full-stack development — Cline / Cursor / Windsurf*