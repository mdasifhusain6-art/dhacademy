<?php
require_once 'config/database.php';
$page_title = "Browse Courses | DH ACADEMY";
$page_description = "Explore our complete catalog of technical and non-technical courses grouped by categories.";
include 'includes/header.php';

$stmt = $pdo->query("SELECT * FROM courses WHERE is_active = 'yes' ORDER BY course_category ASC, created_at DESC");
$all_courses = $stmt->fetchAll();

$courses_by_category = [];
$total_courses = 0;
foreach ($all_courses as $course) {
    $cat = !empty($course['course_category']) ? $course['course_category'] : 'Other Programs';
    $courses_by_category[$cat][] = $course;
    $total_courses++;
}
?>

<!-- Page Header -->
<div class="bg-primary-custom text-white py-5 mb-5 position-relative overflow-hidden" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
  <div class="position-absolute end-0 top-0 opacity-10 blur-5" style="width: 400px; height: 400px; background: radial-gradient(circle, white, transparent); transform: translate(30%, -30%);"></div>
  <div class="container py-4 text-center position-relative z-1">
    <h1 class="display-4 fw-bold mb-3 letter-spacing-1">Course Catalog</h1>
    <p class="lead opacity-90 mb-0 fw-light">Find the perfect skillset to advance your career.</p>
  </div>
</div>

<div class="container pb-5">

  <div class="d-flex justify-content-between align-items-center mb-5 pb-3 border-bottom border-light">
    <h5 class="mb-0 fw-bold text-muted">Explore <span class="text-primary-custom fw-bolder"><?= $total_courses ?></span> amazing courses</h5>
  </div>

  <?php if(empty($courses_by_category)): ?>
      <div class="py-5 text-center">
          <i class="fas fa-search fa-3x text-muted opacity-20 mb-3"></i>
          <h5 class="text-muted fw-bold">No courses available at the moment.</h5>
      </div>
  <?php else: ?>
      <?php foreach($courses_by_category as $category_name => $courses): ?>
      
      <div class="category-section mb-5 pb-4">
          <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom border-light">
              <h3 class="fw-bold mb-0 text-dark letter-spacing-1"><i class="fas fa-layer-group text-warning me-2"></i> <?= htmlspecialchars($category_name) ?></h3>
              <span class="badge bg-light text-primary-custom border border-light px-3 py-2 rounded-pill shadow-sm fw-bold"><i class="fas fa-book-open me-1"></i> <?= count($courses) ?> Courses</span>
          </div>
          
          <div class="row g-4">
          <?php foreach($courses as $course): 
              $is_offer_active = ($course['offer_active'] === 'yes' && (!empty($course['offer_end_date']) && strtotime($course['offer_end_date']) > time()));
              $display_price = $course['course_price'];
          ?>
              <!-- Course Item -->
              <div class="col-md-6 col-lg-4 col-xl-3">
                  <div class="card course-card h-100 rounded-6 shadow-sm border-0 hover-lift">
                      <div class="position-relative img-wrapper">
                          <img src="<?= htmlspecialchars($course['course_image']) ?: 'https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80' ?>" class="card-img-top" alt="<?= htmlspecialchars($course['course_name']) ?>" loading="lazy" />
                          <div class="position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(to bottom, rgba(0,0,0,0.1), transparent 30%);"></div>
                          <div class="position-absolute top-0 start-0 m-3 d-flex flex-column gap-2">
                              <span class="badge bg-primary text-white px-3 py-2 rounded-pill shadow-sm glass-effect" style="border:none;"><i class="fas fa-tag me-1 text-white-50"></i> <?= htmlspecialchars($course['course_category']) ?></span>
                              <?php if($is_offer_active && !empty($course['offer_label'])): ?>
                                  <span class="badge bg-danger px-3 py-2 rounded-pill shadow-md animate-pulse border-0"><i class="fas fa-fire me-1"></i> <?= htmlspecialchars($course['offer_label']) ?></span>
                              <?php endif; ?>
                          </div>
                      </div>
                      <div class="card-body d-flex flex-column p-4">
                          <h5 class="card-title fw-bold text-truncate-2 mb-3"><a href="course-details.php?id=<?= $course['id'] ?>" class="text-dark stretched-link"><?= htmlspecialchars($course['course_name']) ?></a></h5>
                          
                          <p class="text-muted small mb-4 opacity-75" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?= htmlspecialchars($course['short_description']) ?></p>

                          <div class="d-flex justify-content-between align-items-center mb-4 text-muted small fw-medium">
                              <span class="bg-light px-2 py-1 rounded"><i class="far fa-clock text-primary-custom me-1"></i> <?= htmlspecialchars($course['course_duration']) ?></span>
                              <?php if($course['certificate_available'] === 'yes'): ?>
                                  <span class="bg-light px-2 py-1 rounded"><i class="fas fa-certificate text-warning me-1"></i> Cert</span>
                              <?php endif; ?>
                          </div>

                          <div class="mt-auto pt-3 border-top border-light d-flex justify-content-between align-items-center position-relative z-1">
                              <div class="lh-1">
                                  <?php if($is_offer_active && !empty($course['original_price'])): ?>
                                      <span class="text-muted text-decoration-line-through small fw-bold d-block mb-1">₹<?= number_format($course['original_price'], 2) ?></span>
                                  <?php endif; ?>
                                  <span class="fs-5 fw-bolder text-success">₹<?= number_format($display_price, 2) ?></span>
                              </div>
                              <span class="btn btn-action btn-sm btn-rounded px-3 py-2 shadow-sm fw-bold">View Details</span>
                          </div>
                      </div>
                  </div>
              </div>
          <?php endforeach; ?>
          </div>
      </div>
      <?php endforeach; ?>
  <?php endif; ?>

</div>

<?php include 'includes/footer.php'; ?>