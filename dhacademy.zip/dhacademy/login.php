<?php
session_start();
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: dashboard/index.php");
    }
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // Basic brute-force attempt counter
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 0;
    }
    
    if ($_SESSION['login_attempts'] >= 5) {
        if (!isset($_SESSION['lockout_time'])) {
            $_SESSION['lockout_time'] = time() + (15 * 60); // 15 mins lock
        }
        if (time() < $_SESSION['lockout_time']) {
            $error = "Too many failed attempts. Please try again after 15 minutes.";
        } else {
            $_SESSION['login_attempts'] = 0;
            unset($_SESSION['lockout_time']);
        }
    }

    if (empty($error)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND is_active = 1");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Success
            $_SESSION['login_attempts'] = 0;
            session_regenerate_id(true); // Prevent session fixation

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $user['name'];
            $_SESSION['email'] = $user['email'];
            $_SESSION['role'] = $user['role'];
            
            // Handle Remember Me (Mocked via extended session cookie time in real prod)
            if(isset($_POST['remember'])) {
                $params = session_get_cookie_params();
                setcookie(session_name(), session_id(), time() + (86400 * 30), $params["path"], $params["domain"], $params["secure"], $params["httponly"]);
            }

            if ($user['role'] === 'admin') {
                header("Location: admin/dashboard.php");
            } else {
                // If there's an intended redirect, use it, else dashboard
                if (isset($_SESSION['redirect_to'])) {
                    $redirect = $_SESSION['redirect_to'];
                    unset($_SESSION['redirect_to']);
                    header("Location: " . $redirect);
                } else {
                    header("Location: dashboard/index.php");
                }
            }
            exit;
        } else {
            $_SESSION['login_attempts']++;
            // PRD: Incorrect password shows generic error
            $error = "Invalid email or password.";
        }
    }
}

$page_title = "Login | DH ACADEMY";
include 'includes/header.php';
?>

<div class="container py-5 my-5">
  <div class="row justify-content-center">
    <div class="col-md-6 col-lg-5">
      <div class="card shadow-4-strong rounded-6 border-0">
        <div class="card-body p-4 p-md-5">
          
          <div class="text-center mb-4">
            <div class="bg-primary-custom text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3" style="width: 60px; height: 60px;">
                <i class="fas fa-user-lock fs-3"></i>
            </div>
            <h4 class="fw-bold">Welcome Back</h4>
            <p class="text-muted">Login to access your dashboard</p>
          </div>

          <?php if(!empty($error)): ?>
            <div class="alert alert-danger rounded-4 py-2 small fw-bold"> <i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <form action="login.php" method="POST">
            
            <div class="form-outline mb-4" data-mdb-input-init>
              <input type="email" id="email" name="email" class="form-control form-control-lg" required />
              <label class="form-label" for="email">Email address</label>
            </div>

            <div class="form-outline mb-4" data-mdb-input-init>
              <input type="password" id="password" name="password" class="form-control form-control-lg" required />
              <label class="form-label" for="password">Password</label>
            </div>

            <div class="row mb-4">
              <div class="col d-flex justify-content-center">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" value="1" id="remember" name="remember" checked />
                  <label class="form-check-label text-muted" for="remember"> Remember me </label>
                </div>
              </div>

              <div class="col text-end">
                <a href="#!" class="text-primary-custom text-decoration-none small fw-bold">Forgot password?</a>
              </div>
            </div>

            <button type="submit" class="btn btn-action btn-lg btn-block btn-rounded mb-4 shadow-1-strong hover-lift">Sign in</button>

            <div class="text-center text-muted small">
              <p>Not a member? <a href="register.php" class="text-primary-custom text-decoration-none fw-bold">Register here</a></p>
            </div>
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>
