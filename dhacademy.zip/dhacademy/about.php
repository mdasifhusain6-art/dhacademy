<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - DH ACADEMY</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-graduation-cap me-2 text-warning"></i>DH ACADEMY
            </a>
            <button class="navbar-toggler" type="button" data-mdb-collapse-init data-mdb-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="courses.php">Courses</a></li>
                    <li class="nav-item"><a class="nav-link active" href="about.php">About Us</a></li>
                    <li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
                </ul>
                <div class="d-flex align-items-center">
                    <a href="login.php" class="btn btn-outline-light btn-rounded me-3" data-mdb-ripple-init>Login</a>
                    <a href="register.php" class="btn btn-action btn-rounded" data-mdb-ripple-init>Sign Up</a>
                </div>
            </div>
        </div>
    </nav>

    <div style="margin-top: 60px;">

        <div class="bg-primary-custom text-white py-5 text-center">
            <div class="container">
                <h1 class="fw-bold">About DH ACADEMY</h1>
                <p class="lead mb-0">Empowering futures through accessible digital education.</p>
            </div>
        </div>

        <section class="py-5">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-6 mb-4 mb-md-0">
                        <img src="https://images.unsplash.com/photo-1513258496099-481620202add?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                            alt="Students" class="img-fluid rounded-6 shadow-4-strong">
                    </div>
                    <div class="col-md-6">
                        <h2 class="fw-bold text-primary-custom mb-3">Our Mission</h2>
                        <p class="text-muted">At DH ACADEMY, our mission is to provide high-quality, practical, and
                            affordable education to students across the globe. We believe that financial constraints
                            should never be a barrier to learning.</p>
                        <p class="text-muted">Whether you are looking to become a proficient Full Stack Developer, a
                            certified Accountant, or a trained Teacher, we have meticulously crafted courses to guide
                            you every step of the way.</p>

                        <div class="row mt-4">
                            <div class="col-6 mb-3">
                                <h3 class="fw-bold text-secondary-custom mb-0">10k+</h3>
                                <p class="small text-muted text-uppercase">Students Enrolled</p>
                            </div>
                            <div class="col-6 mb-3">
                                <h3 class="fw-bold text-secondary-custom mb-0">50+</h3>
                                <p class="small text-muted text-uppercase">Expert Courses</p>
                            </div>
                        </div>
                        <a href="courses.php" class="btn btn-primary-custom btn-rounded" data-mdb-ripple-init>View Our
                            Courses</a>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <footer class="text-left py-4 bg-primary-custom text-white mt-auto">
        <div class="footer-bottom p-3 text-center">
            <p class="mb-0">&copy; 2026 DH ACADEMY. All rights reserved.</p>
        </div>
    </footer>

    <a href="https://wa.me/1234567890" class="whatsapp-float" target="_blank" rel="noopener noreferrer">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
</body>

</html>