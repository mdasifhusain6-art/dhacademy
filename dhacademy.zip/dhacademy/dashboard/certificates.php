<?php
require_once '../includes/auth-check.php';
require_once '../config/database.php';

$user_id = $_SESSION['user_id'];

// Fetch issued certificates
$stmt = $pdo->prepare("
    SELECT cr.*, c.course_name, c.course_image 
    FROM certificates cr
    JOIN courses c ON cr.course_id = c.id
    WHERE cr.user_id = ? AND cr.status = 'issued'
    ORDER BY cr.issue_date DESC
");
$stmt->execute([$user_id]);
$certificates = $stmt->fetchAll();

$page_title = "My Certificates | DH ACADEMY";
include '../includes/header.php';
?>

<div class="bg-primary-custom py-5 mb-5 position-relative overflow-hidden" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
    <div class="position-absolute end-0 top-0 opacity-10 blur-5" style="width: 300px; height: 300px; background: radial-gradient(circle, white, transparent); transform: translate(30%, -30%);"></div>
    <div class="container text-white position-relative z-1">
        <h2 class="display-6 fw-bold mb-2 letter-spacing-1">My Certificates</h2>
        <p class="mb-0 opacity-90 fw-light fs-5">View and download your earned certificates.</p>
    </div>
</div>

<div class="container py-4 pb-5">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden position-sticky" style="top: 100px;">
                <div class="list-group list-group-flush rounded-6 list-group-borderless">
                    <a href="index.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-home me-3 text-primary-custom opacity-50"></i>Dashboard Home</a>
                    <a href="my-courses.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-book-reader me-3 text-primary-custom opacity-50"></i>My Courses</a>
                    <a href="certificates.php" class="list-group-item list-group-item-action py-3 px-4 fw-bold active border-0"><i class="fas fa-certificate me-3 text-white"></i>Certificates</a>
                    <a href="profile.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-user-cog me-3 text-primary-custom opacity-50"></i>Profile Settings</a>
                </div>
                
                <div class="p-3">
                    <a href="../courses.php" class="btn btn-warning btn-rounded w-100 shadow-sm py-2 px-3 fw-bold mb-3 hover-lift"><i class="fas fa-search me-2"></i>Browse More</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-9">
            
            <?php if(count($certificates) > 0): ?>
                <div class="row g-4">
                    <?php foreach($certificates as $cert): ?>
                    <div class="col-md-6 col-xl-4">
                        <div class="card shadow-sm border-0 rounded-6 h-100 hover-lift bg-white">
                            <div class="card-body p-4 text-center d-flex flex-column">
                                
                                <div class="bg-success text-white rounded-circle d-inline-flex align-items-center justify-content-center mx-auto mb-4 shadow-sm" style="width: 70px; height: 70px;">
                                    <i class="fas fa-award fs-3"></i>
                                </div>
                                
                                <h6 class="fw-bold text-dark mb-2 text-truncate-2" style="min-height: 44px;"><?= htmlspecialchars($cert['course_name']) ?></h6>
                                <p class="text-success small fw-medium mb-4"><i class="fas fa-check-circle me-1 opacity-75"></i> Issued: <?= date('M d, Y', strtotime($cert['issue_date'])) ?></p>
                                
                                <div class="mt-auto pt-3 border-top border-light">
                                    <a href="<?= htmlspecialchars($cert['certificate_link']) ?>" target="_blank" class="btn btn-action py-2 btn-rounded w-100 shadow-sm fw-bold"><i class="fas fa-download me-2"></i>Download</a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="card shadow-sm border-0 rounded-6 text-center py-5 bg-white">
                    <div class="card-body py-5">
                        <img src="https://cdni.iconscout.com/illustration/premium/thumb/no-data-found-4344458-3613886.png" alt="No Certificates" style="width: 200px; opacity: 0.5;" class="mb-4">
                        <h4 class="fw-bold text-dark">No Certificates Yet</h4>
                        <p class="text-muted mb-4 max-width-500 mx-auto">Complete your enrolled courses and request your certificate via WhatsApp to see them appear here.</p>
                        <a href="my-courses.php" class="btn btn-action btn-lg btn-rounded px-5 shadow-1-strong hover-lift">Go to My Courses</a>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
