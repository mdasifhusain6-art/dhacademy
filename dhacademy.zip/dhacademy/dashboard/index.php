<?php
require_once '../includes/auth-check.php';
require_once '../config/database.php';

$user_id = $_SESSION['user_id'];

// Get counts
$courses_stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ? AND payment_status = 'success'");
$courses_stmt->execute([$user_id]);
$enrolled_count = $courses_stmt->fetchColumn();

$cert_stmt = $pdo->prepare("SELECT COUNT(*) FROM certificates WHERE user_id = ? AND status = 'issued'");
$cert_stmt->execute([$user_id]);
$cert_count = $cert_stmt->fetchColumn();

// Get recent courses (limit 3)
$recent_stmt = $pdo->prepare("
    SELECT c.id, c.course_name, c.course_image, c.course_duration, c.instructor_name 
    FROM orders o
    JOIN courses c ON o.course_id = c.id
    WHERE o.user_id = ? AND o.payment_status = 'success'
    ORDER BY o.created_at DESC
    LIMIT 3
");
$recent_stmt->execute([$user_id]);
$recent_courses = $recent_stmt->fetchAll();

$page_title = "My Dashboard | DH ACADEMY";
include '../includes/header.php';
?>

<div class="bg-primary-custom py-5 mb-5 position-relative overflow-hidden" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
    <div class="position-absolute end-0 top-0 opacity-10 blur-5" style="width: 300px; height: 300px; background: radial-gradient(circle, white, transparent); transform: translate(30%, -30%);"></div>
    <div class="container text-white position-relative z-1">
        <h2 class="display-6 fw-bold mb-2 letter-spacing-1">Welcome back, <?= htmlspecialchars($_SESSION['name']) ?>! 👋</h2>
        <p class="mb-0 opacity-90 fw-light fs-5">Here's an overview of your learning progress.</p>
    </div>
</div>

<div class="container py-4 pb-5">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden position-sticky" style="top: 100px;">
                <div class="list-group list-group-flush rounded-6 list-group-borderless">
                    <a href="index.php" class="list-group-item list-group-item-action py-3 px-4 fw-bold active border-0"><i class="fas fa-home me-3 text-white"></i>Dashboard Home</a>
                    <a href="my-courses.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-book-reader me-3 text-primary-custom opacity-50"></i>My Courses</a>
                    <a href="certificates.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-certificate me-3 text-primary-custom opacity-50"></i>Certificates</a>
                    <a href="profile.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-user-cog me-3 text-primary-custom opacity-50"></i>Profile Settings</a>
                </div>
                
                <div class="p-3">
                    <a href="../courses.php" class="btn btn-warning btn-rounded w-100 shadow-sm py-2 px-3 fw-bold mb-3 hover-lift"><i class="fas fa-search me-2"></i>Browse More</a>
                </div>
            </div>
            
            <div class="card shadow-sm border-0 rounded-6 bg-light d-none d-lg-block">
                <div class="card-body text-center p-4">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 shadow-sm text-primary-custom" style="width: 50px; height: 50px;">
                        <i class="fas fa-headset fs-4"></i>
                    </div>
                    <h6 class="fw-bold text-dark mb-2">Need Help?</h6>
                    <p class="small text-muted mb-3">Contact our support team for any dashboard issues.</p>
                    <a href="https://wa.me/1234567890" target="_blank" class="btn btn-outline-success btn-sm btn-rounded w-100 shadow-0 fw-bold border-2"><i class="fab fa-whatsapp me-2 fs-6"></i>WhatsApp Us</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-9">
            
            <!-- Quick Stats -->
            <div class="row g-4 mb-5">
                <div class="col-md-6">
                    <div class="card shadow-md border-0 rounded-6 position-relative overflow-hidden hover-lift" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
                        <div class="position-absolute end-0 bottom-0 opacity-10" style="transform: translate(20%, 20%);">
                            <i class="fas fa-layer-group" style="font-size: 8rem; color: white;"></i>
                        </div>
                        <div class="card-body p-4 p-xl-5 d-flex align-items-center position-relative z-1">
                            <div class="bg-white rounded-circle d-flex align-items-center justify-content-center text-primary-custom me-4 shadow-sm animation-float" style="width: 70px; height: 70px;">
                                <i class="fas fa-layer-group fs-2"></i>
                            </div>
                            <div class="text-white">
                                <h1 class="fw-bolder mb-1 display-5 text-white"><?= $enrolled_count ?></h1>
                                <p class="mb-0 fw-bold opacity-90 text-uppercase letter-spacing-1 small glass-effect px-2 py-1 rounded d-inline-block">Enrolled Courses</p>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card shadow-md border-0 rounded-6 position-relative overflow-hidden hover-lift" style="background: linear-gradient(135deg, #FF8C00 0%, #FFA500 100%);">
                        <div class="position-absolute end-0 bottom-0 opacity-20" style="transform: translate(20%, 20%);">
                            <i class="fas fa-award" style="font-size: 8rem; color: white;"></i>
                        </div>
                        <div class="card-body p-4 p-xl-5 d-flex align-items-center position-relative z-1">
                            <div class="bg-white rounded-circle d-flex align-items-center justify-content-center text-warning me-4 shadow-sm animation-float" style="width: 70px; height: 70px; animation-delay: 0.5s;">
                                <i class="fas fa-award fs-2"></i>
                            </div>
                            <div class="text-white">
                                <h1 class="fw-bolder mb-1 display-5 text-white"><?= $cert_count ?></h1>
                                <p class="mb-0 fw-bold opacity-90 text-uppercase letter-spacing-1 small glass-effect px-2 py-1 rounded d-inline-block border-0 text-dark">Earned Certificates</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Courses -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h4 class="fw-bold mb-0">Continue Learning</h4>
                <?php if($enrolled_count > 3): ?>
                  <a href="my-courses.php" class="btn btn-link text-primary-custom fw-bold px-0 shadow-0">View All <i class="fas fa-arrow-right ms-1"></i></a>
                <?php endif; ?>
            </div>

            <?php if(count($recent_courses) > 0): ?>
                <div class="row g-4">
                    <?php foreach($recent_courses as $course): ?>
                    <div class="col-md-6 col-lg-4">
                        <div class="card h-100 shadow-sm border-0 rounded-5 hover-lift">
                            <img src="<?= htmlspecialchars($course['course_image']) ?>" class="card-img-top" style="height: 160px; object-fit: cover; border-top-left-radius: 1rem; border-top-right-radius: 1rem;" alt="<?= htmlspecialchars($course['course_name']) ?>">
                            <div class="card-body p-4">
                                <h6 class="fw-bold text-truncate-2 mb-3"><a href="my-courses.php" class="text-dark text-decoration-none"><?= htmlspecialchars($course['course_name']) ?></a></h6>
                                <p class="text-muted small mb-3"><i class="fas fa-chalkboard-teacher text-warning me-2"></i><?= htmlspecialchars($course['instructor_name'] ?: 'DH Academy Expert') ?></p>
                                
                                <a href="my-courses.php" class="btn btn-light btn-rounded w-100 shadow-0 border fw-bold text-primary-custom hover-bg-primary">Open Folder <i class="fas fa-external-link-alt ms-1 small"></i></a>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="card shadow-0 border border-dashed rounded-6 text-center py-5 bg-light">
                    <div class="card-body">
                        <i class="fas fa-folder-open fa-3x text-muted opacity-20 mb-3"></i>
                        <h5 class="text-muted fw-bold">No courses yet.</h5>
                        <p class="text-muted small mb-4">Discover our top courses and start learning today!</p>
                        <a href="../courses.php" class="btn btn-action btn-rounded px-4 shadow-1-strong">Explore Catalog</a>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
