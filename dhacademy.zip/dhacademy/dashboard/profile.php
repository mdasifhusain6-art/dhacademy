<?php
require_once '../includes/auth-check.php';
require_once '../config/database.php';

$user_id = $_SESSION['user_id'];
$success_msg = '';
$error_msg = '';

// Fetch current user details
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Profile Update
    if (isset($_POST['update_profile'])) {
        $name = trim($_POST['name']);
        $phone = trim($_POST['phone']);
        
        if (empty($name)) {
            $error_msg = "Name cannot be empty.";
        } else {
            $update_stmt = $pdo->prepare("UPDATE users SET name = ?, phone = ? WHERE id = ?");
            if ($update_stmt->execute([$name, $phone, $user_id])) {
                $_SESSION['name'] = $name; // Update session
                $user['name'] = $name;
                $user['phone'] = $phone;
                $success_msg = "Profile updated successfully.";
            } else {
                $error_msg = "Profile update failed.";
            }
        }
    }
    
    // Password Update
    if (isset($_POST['update_password'])) {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
            $error_msg = "All password fields are required.";
        } else if (!password_verify($current_password, $user['password'])) {
            $error_msg = "Current password is incorrect.";
        } else if ($new_password !== $confirm_password) {
            $error_msg = "New passwords do not match.";
        } else if (strlen($new_password) < 8) {
            $error_msg = "New password must be at least 8 characters.";
        } else {
            $hashed = password_hash($new_password, PASSWORD_BCRYPT);
            $update_pwd = $pdo->prepare("UPDATE users SET password = ? WHERE id = ?");
            if ($update_pwd->execute([$hashed, $user_id])) {
                $success_msg = "Password updated successfully.";
            } else {
                $error_msg = "Failed to update password.";
            }
        }
    }
}

$page_title = "My Profile | DH ACADEMY";
include '../includes/header.php';
?>

<div class="bg-primary-custom py-5 mb-5 position-relative overflow-hidden" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
    <div class="position-absolute end-0 top-0 opacity-10 blur-5" style="width: 300px; height: 300px; background: radial-gradient(circle, white, transparent); transform: translate(30%, -30%);"></div>
    <div class="container text-white position-relative z-1">
        <h2 class="display-6 fw-bold mb-0 letter-spacing-1">My Profile Settings</h2>
    </div>
</div>

<div class="container py-4 pb-5">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden position-sticky" style="top: 100px;">
                <div class="list-group list-group-flush rounded-6 list-group-borderless">
                    <a href="index.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-home me-3 text-primary-custom opacity-50"></i>Dashboard Home</a>
                    <a href="my-courses.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-book-reader me-3 text-primary-custom opacity-50"></i>My Courses</a>
                    <a href="certificates.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-certificate me-3 text-primary-custom opacity-50"></i>Certificates</a>
                    <a href="profile.php" class="list-group-item list-group-item-action py-3 px-4 fw-bold active border-0"><i class="fas fa-user-cog me-3 text-white"></i>Profile Settings</a>
                </div>
                
                <div class="p-3">
                    <a href="../courses.php" class="btn btn-warning btn-rounded w-100 shadow-sm py-2 px-3 fw-bold mb-3 hover-lift"><i class="fas fa-search me-2"></i>Browse More</a>
                </div>
            </div>
            
            <div class="card shadow-sm border-0 rounded-6 bg-light d-none d-lg-block">
                <div class="card-body text-center p-4">
                    <div class="bg-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3 shadow-sm text-primary-custom" style="width: 50px; height: 50px;">
                        <i class="fas fa-headset fs-4"></i>
                    </div>
                    <h6 class="fw-bold text-dark mb-2">Need Help?</h6>
                    <p class="small text-muted mb-3">Contact our support team for any dashboard issues.</p>
                    <a href="https://wa.me/1234567890" target="_blank" class="btn btn-outline-success btn-sm btn-rounded w-100 shadow-0 fw-bold border-2"><i class="fab fa-whatsapp me-2 fs-6"></i>WhatsApp Us</a>
                </div>
            </div>
        </div>

        <!-- Main Content Core -->
        <div class="col-lg-9">
            
            <?php if(!empty($success_msg)): ?>
               <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm" role="alert">
                    <i class="fas fa-check-circle me-2"></i><strong>Success!</strong> <?= $success_msg ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(!empty($error_msg)): ?>
               <div class="alert alert-danger alert-dismissible fade show rounded-4 shadow-sm" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i><strong>Error!</strong> <?= $error_msg ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="row g-4">
                <!-- Profile Edit Form -->
                <div class="col-md-6">
                    <div class="card shadow-sm border-0 rounded-6 h-100">
                        <div class="card-header bg-white border-bottom py-3">
                            <h5 class="fw-bold mb-0"><i class="fas fa-user text-primary-custom me-2"></i> Personal Details</h5>
                        </div>
                        <div class="card-body p-4 p-md-5">
                            
                            <form action="profile.php" method="POST">
                                <input type="hidden" name="update_profile" value="1">
                                
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="text" id="name" name="name" class="form-control" value="<?= htmlspecialchars($user['name']) ?>" required />
                                    <label class="form-label" for="name">Full Name</label>
                                </div>
                                
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <!-- Email is read-only for security, require manual admin change if needed -->
                                    <input type="email" id="email" class="form-control" value="<?= htmlspecialchars($user['email']) ?>" readonly disabled />
                                    <label class="form-label" for="email">Email Address <span class="text-danger small">(Read-only)</span></label>
                                </div>
                                
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="tel" id="phone" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone']) ?>" pattern="[0-9]{10}" title="10 digit valid mobile number" />
                                    <label class="form-label" for="phone">WhatsApp Phone</label>
                                </div>
                                
                                <button type="submit" class="btn btn-primary-custom btn-rounded px-4 w-100 shadow-0"><i class="fas fa-save me-2"></i>Save Changes</button>
                            </form>

                        </div>
                    </div>
                </div>

                <!-- Password Edit Form -->
                <div class="col-md-6">
                    <div class="card shadow-sm border-0 rounded-6 h-100">
                        <div class="card-header bg-white border-bottom py-3">
                            <h5 class="fw-bold mb-0"><i class="fas fa-lock text-warning me-2"></i> Security</h5>
                        </div>
                        <div class="card-body p-4 p-md-5">
                            
                            <form action="profile.php" method="POST">
                                <input type="hidden" name="update_password" value="1">
                                
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="password" id="current_password" name="current_password" class="form-control" required />
                                    <label class="form-label" for="current_password">Current Password</label>
                                </div>
                                
                                <hr class="opacity-10 my-4">

                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="password" id="new_password" name="new_password" class="form-control" minlength="8" required />
                                    <label class="form-label" for="new_password">New Password</label>
                                </div>
                                
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="password" id="confirm_password" name="confirm_password" class="form-control" minlength="8" required />
                                    <label class="form-label" for="confirm_password">Confirm New Password</label>
                                </div>
                                
                                <button type="submit" class="btn btn-warning btn-rounded px-4 w-100 shadow-0 text-dark fw-bold"><i class="fas fa-key me-2"></i>Update Password</button>
                            </form>

                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
