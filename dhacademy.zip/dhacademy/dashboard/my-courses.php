<?php
require_once '../includes/auth-check.php';
require_once '../config/database.php';

$user_id = $_SESSION['user_id'];

// Fetch all enrolled courses
$stmt = $pdo->prepare("
    SELECT c.*, o.id as order_id, o.created_at as enrolled_date 
    FROM orders o
    JOIN courses c ON o.course_id = c.id
    WHERE o.user_id = ? AND o.payment_status = 'success'
    ORDER BY o.created_at DESC
");
$stmt->execute([$user_id]);
$courses = $stmt->fetchAll();

// Fetch issued certificates to map against courses
$cert_stmt = $pdo->prepare("SELECT course_id FROM certificates WHERE user_id = ? AND status = 'issued'");
$cert_stmt->execute([$user_id]);
$issued_certs = $cert_stmt->fetchAll(PDO::FETCH_COLUMN);

$page_title = "My Courses | DH ACADEMY";
include '../includes/header.php';
?>

<div class="bg-primary-custom py-4 mb-4">
    <div class="container text-white">
        <h2 class="fw-bold mb-0">My Courses</h2>
        <p class="mb-0 opacity-75">Access all your purchased materials here.</p>
    </div>
</div>

<div class="container py-4 pb-5">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-3">
            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden position-sticky" style="top: 100px;">
                <div class="list-group list-group-flush rounded-6 list-group-borderless">
                    <a href="index.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-home me-3 text-primary-custom opacity-50"></i>Dashboard Home</a>
                    <a href="my-courses.php" class="list-group-item list-group-item-action py-3 px-4 fw-bold active border-0"><i class="fas fa-book-reader me-3 text-white"></i>My Courses</a>
                    <a href="certificates.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-certificate me-3 text-primary-custom opacity-50"></i>Certificates</a>
                    <a href="profile.php" class="list-group-item list-group-item-action py-3 px-4 fw-medium text-muted hover-bg-light transition-fast"><i class="fas fa-user-cog me-3 text-primary-custom opacity-50"></i>Profile Settings</a>
                </div>
                
                <div class="p-3">
                    <a href="../courses.php" class="btn btn-warning btn-rounded w-100 shadow-sm py-2 px-3 fw-bold mb-3 hover-lift"><i class="fas fa-search me-2"></i>Browse More</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-9">
            
            <?php if(count($courses) > 0): ?>
                <div class="row g-4">
                    <?php foreach($courses as $course): 
                        $has_cert = in_array($course['id'], $issued_certs);
                    ?>
                    <div class="col-md-6 mt-0">
                        <div class="card course-card h-100 rounded-6 shadow-sm border-0 hover-lift flex-column d-flex">
                            <div class="position-relative img-wrapper">
                                <img src="<?= htmlspecialchars($course['course_image']) ?: 'https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80' ?>" class="card-img-top" alt="<?= htmlspecialchars($course['course_name']) ?>" loading="lazy" />
                                <div class="position-absolute top-0 start-0 m-3 d-flex flex-column gap-2">
                                    <span class="badge bg-success text-white px-3 py-2 rounded-pill shadow-sm glass-effect" style="border:none;"><i class="fas fa-check-circle me-1 text-white-50"></i> Enrolled</span>
                                </div>
                            </div>
                            <div class="card-body d-flex flex-column p-4">
                                <h5 class="card-title fw-bold text-truncate-2 mb-2"><a href="../api/course-access.php?course_id=<?= $course['id'] ?>" target="_blank" class="text-dark text-decoration-none"><?= htmlspecialchars($course['course_name']) ?></a></h5>
                                <p class="text-muted small fw-medium mb-4"><i class="far fa-calendar-alt text-primary-custom me-2 opacity-75"></i> Purchased: <?= date('M d, Y', strtotime($course['enrolled_date'])) ?></p>

                                <div class="mt-auto d-flex flex-column gap-3">
                                    <a href="../api/course-access.php?course_id=<?= $course['id'] ?>" target="_blank" class="btn btn-action py-2 btn-rounded w-100 shadow-sm fw-bold"><i class="fab fa-google-drive me-2"></i>Access Materials</a>
                                    
                                    <?php if($course['certificate_available'] === 'yes'): ?>
                                        <?php if($has_cert): ?>
                                            <a href="certificates.php" class="btn bg-light py-2 text-success btn-rounded w-100 shadow-0 fw-bold border-0 hover-bg-light"><i class="fas fa-award me-2"></i>View Certificate</a>
                                        <?php else: ?>
                                            <?php 
                                                $waMsg = urlencode("Hello, I have completed the course '{$course['course_name']}' associated with email {$_SESSION['email']}. Please verify and issue my certificate."); 
                                            ?>
                                            <a href="https://wa.me/1234567890?text=<?= $waMsg ?>" target="_blank" class="btn btn-outline-success py-2 border-2 text-success btn-rounded w-100 shadow-0 fw-bold"><i class="fab fa-whatsapp fs-5 me-2"></i>Request Certificate</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="card shadow-sm border-0 rounded-6 text-center py-5 bg-white">
                    <div class="card-body py-5">
                        <img src="https://cdni.iconscout.com/illustration/premium/thumb/empty-cart-2130356-1800917.png" alt="Empty" style="width: 200px; opacity: 0.5;" class="mb-4">
                        <h4 class="fw-bold text-dark">You haven't enrolled in any courses</h4>
                        <p class="text-muted mb-4 max-width-500 mx-auto">Explore our wide range of technical and non-technical courses to kickstart your career.</p>
                        <a href="../courses.php" class="btn btn-action btn-lg btn-rounded px-5 shadow-1-strong hover-lift">Browse Catalog</a>
                    </div>
                </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
