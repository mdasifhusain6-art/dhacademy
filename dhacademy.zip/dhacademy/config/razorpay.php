<?php
// config/razorpay.php
// Placeholder API Keys for Razorpay. Do not commit actual live keys.

define('RAZORPAY_KEY_ID', 'rzp_test_placeholder_key_id');
define('RAZORPAY_KEY_SECRET', 'placeholder_secret_key');
?>
