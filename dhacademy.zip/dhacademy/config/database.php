<?php
// config/database.php

// DB Credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Assuming default XAMPP user
define('DB_PASS', '');     // Assuming default XAMPP empty password
define('DB_NAME', 'dhacademy');

try {
    // Create PDO connection
    $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // Return a JSON error or simple text based on where it's called, but for now just die
    die("Database connection failed: " . $e->getMessage());
}
?>
