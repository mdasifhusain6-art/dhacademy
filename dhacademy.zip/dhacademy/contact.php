<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - DH ACADEMY</title>

    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="assets/css/style.css">
</head>

<body>

    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="index.php">
                <i class="fas fa-graduation-cap me-2 text-warning"></i>DH ACADEMY
            </a>
            <button class="navbar-toggler" type="button" data-mdb-collapse-init data-mdb-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="courses.php">Courses</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php">About Us</a></li>
                    <li class="nav-item"><a class="nav-link active" href="contact.php">Contact</a></li>
                </ul>
                <div class="d-flex align-items-center">
                    <a href="login.php" class="btn btn-outline-light btn-rounded me-3" data-mdb-ripple-init>Login</a>
                    <a href="register.php" class="btn btn-action btn-rounded" data-mdb-ripple-init>Sign Up</a>
                </div>
            </div>
        </div>
    </nav>

    <div style="margin-top: 60px;">

        <div class="bg-primary-custom text-white py-5 text-center">
            <div class="container">
                <h1 class="fw-bold">Contact Us</h1>
                <p class="lead mb-0">We are here to help you via email or WhatsApp.</p>
            </div>
        </div>

        <section class="py-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card shadow-4-strong">
                            <div class="card-body p-5">
                                <div class="row text-center mb-5">
                                    <div class="col-md-4 mb-3">
                                        <i class="fas fa-phone fa-3x text-primary-custom mb-3"></i>
                                        <h5 class="fw-bold">Phone</h5>
                                        <p class="text-muted">+91 9876543210</p>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <i class="fas fa-envelope fa-3x text-primary-custom mb-3"></i>
                                        <h5 class="fw-bold">Email</h5>
                                        <p class="text-muted">support@dhacademy.com</p>
                                    </div>
                                    <div class="col-md-4 mb-3">
                                        <i class="fab fa-whatsapp fa-3x text-success mb-3"></i>
                                        <h5 class="fw-bold">WhatsApp</h5>
                                        <a href="https://wa.me/1234567890"
                                            class="btn btn-success btn-sm btn-rounded mt-2"><i
                                                class="fab fa-whatsapp me-2"></i> Message Us</a>
                                    </div>
                                </div>

                                <hr class="mb-5">

                                <h4 class="fw-bold text-center mb-4">Send us a Message</h4>

                                <form>
                                    <!-- Name input -->
                                    <div class="form-outline mb-4" data-mdb-input-init>
                                        <input type="text" id="contactName" class="form-control" />
                                        <label class="form-label" for="contactName">Your Name</label>
                                    </div>

                                    <!-- Email input -->
                                    <div class="form-outline mb-4" data-mdb-input-init>
                                        <input type="email" id="contactEmail" class="form-control" />
                                        <label class="form-label" for="contactEmail">Email address</label>
                                    </div>

                                    <!-- Message input -->
                                    <div class="form-outline mb-4" data-mdb-input-init>
                                        <textarea class="form-control" id="contactMessage" rows="4"></textarea>
                                        <label class="form-label" for="contactMessage">Message</label>
                                    </div>

                                    <!-- Submit button -->
                                    <button type="submit" class="btn btn-primary-custom btn-block mb-4 btn-rounded"
                                        data-mdb-ripple-init>Send Message</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

    </div>

    <footer class="text-left py-4 bg-primary-custom text-white mt-auto">
        <div class="footer-bottom p-3 text-center">
            <p class="mb-0">&copy; 2026 DH ACADEMY. All rights reserved.</p>
        </div>
    </footer>

    <a href="https://wa.me/1234567890" class="whatsapp-float" target="_blank" rel="noopener noreferrer">
        <i class="fab fa-whatsapp"></i>
    </a>

    <script type="text/javascript"
        src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
</body>

</html>