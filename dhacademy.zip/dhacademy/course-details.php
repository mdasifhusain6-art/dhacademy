<?php
require_once 'config/database.php';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: courses.php");
    exit;
}

$course_id = (int)$_GET['id'];
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ? AND is_active = 'yes'");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    header("Location: courses.php");
    exit;
}

// Fetch Reviews Data
$review_stmt = $pdo->prepare("SELECT r.*, u.name as reviewer_name FROM reviews r JOIN users u ON r.user_id = u.id WHERE r.course_id = ? AND r.is_visible = 1 ORDER BY r.created_at DESC");
$review_stmt->execute([$course_id]);
$reviews = $review_stmt->fetchAll();

$avg_rating = 0;
if (count($reviews) > 0) {
    $sum = array_sum(array_column($reviews, 'rating'));
    $avg_rating = round($sum / count($reviews), 1);
}

// Check Offer
$is_offer_active = ($course['offer_active'] === 'yes' && (!empty($course['offer_end_date']) && strtotime($course['offer_end_date']) > time()));
$display_price = $course['course_price'];
$syllabus_json = $course['syllabus'] ? json_decode($course['syllabus'], true) : [];

// --- SEO & Header Setup ---
$page_title = (!empty($course['seo_title'])) ? $course['seo_title'] . " | DH ACADEMY" : $course['course_name'] . " | DH ACADEMY";
$page_description = (!empty($course['seo_description'])) ? $course['seo_description'] : substr(strip_tags($course['course_description']), 0, 155);

include 'includes/header.php';

// Check if logged in user already owns this course
$has_access = false;
if (isset($_SESSION['user_id'])) {
    $check_stmt = $pdo->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND payment_status = 'success'");
    $check_stmt->execute([$_SESSION['user_id'], $course_id]);
    if ($check_stmt->fetch()) {
        $has_access = true;
    }
}
?>

<!-- Schema JSON-LD -->
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Course",
  "name": "<?= htmlspecialchars($course['course_name']) ?>",
  "description": "<?= htmlspecialchars(strip_tags($course['short_description'])) ?>",
  "provider": {
    "@type": "Organization",
    "name": "DH ACADEMY",
    "sameAs": "http://example.com"
  },
  "offers": {
    "@type": "Offer",
    "price": "<?= $display_price ?>",
    "priceCurrency": "INR"
  }
}
</script>

<!-- Breadcrumb & Header -->
<div class="bg-primary-custom text-white pt-5 pb-5 position-relative overflow-hidden" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
  <div class="position-absolute end-0 top-0 opacity-10 blur-5" style="width: 400px; height: 400px; background: radial-gradient(circle, white, transparent); transform: translate(30%, -30%);"></div>
  <div class="container pb-md-5 position-relative z-1">
    <nav aria-label="breadcrumb">
      <ol class="breadcrumb mb-2">
        <li class="breadcrumb-item"><a href="index.php" class="text-white opacity-70 text-decoration-none hover-text-white transition-fast">Home</a></li>
        <li class="breadcrumb-item"><a href="courses.php" class="text-white opacity-70 text-decoration-none hover-text-white transition-fast">Courses</a></li>
        <li class="breadcrumb-item active text-white fw-bold" aria-current="page"><?= htmlspecialchars($course['course_name']) ?></li>
      </ol>
    </nav>

    <div class="row mt-4">
      <div class="col-lg-8">
        <span class="badge glass-effect text-light border-0 mb-3 px-3 py-2 rounded-pill shadow-sm"><i class="fas fa-layer-group text-warning me-1"></i> <?= htmlspecialchars($course['course_category']) ?></span>
        <h1 class="display-4 fw-bolder mb-3 letter-spacing-1"><?= htmlspecialchars($course['course_name']) ?></h1>
        <p class="lead opacity-90 mb-4 fw-light" style="font-size: 1.25rem;"><?= htmlspecialchars($course['short_description']) ?></p>
        
        <div class="d-flex flex-wrap align-items-center gap-4 text-white opacity-90 small mb-4 fw-medium">
          <?php if($avg_rating > 0): ?>
          <span class="d-flex align-items-center bg-white bg-opacity-10 px-3 py-2 rounded-pill">
            <span class="text-warning me-1 fw-bold fs-6"><?= $avg_rating ?></span>
            <i class="fas fa-star text-warning"></i>
            <span class="ms-2 opacity-75">(<?= count($reviews) ?> reviews)</span>
          </span>
          <?php endif; ?>
          <span class="bg-white bg-opacity-10 px-3 py-2 rounded-pill"><i class="far fa-clock me-2 text-warning"></i> <?= htmlspecialchars($course['course_duration']) ?></span>
          <span class="bg-white bg-opacity-10 px-3 py-2 rounded-pill"><i class="fas fa-signal me-2 text-warning"></i> <?= htmlspecialchars($course['course_level']) ?></span>
          <span class="bg-white bg-opacity-10 px-3 py-2 rounded-pill"><i class="fas fa-globe me-2 text-warning"></i> <?= htmlspecialchars($course['course_language']) ?></span>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="container" style="margin-top: -50px;">
  <div class="row">

    <!-- Left Content -->
    <div class="col-lg-8 mb-5 mb-lg-0">
      
      <!-- Preview Image (Mobile Stacks Here) -->
      <div class="card shadow-md rounded-6 border-0 mb-5 d-lg-none overflow-hidden">
        <img src="<?= htmlspecialchars($course['course_image']) ?>" class="img-fluid" alt="<?= htmlspecialchars($course['course_name']) ?>">
      </div>

      <!-- Description -->
      <div class="card shadow-sm border-0 rounded-6 mb-5">
        <div class="card-body p-4 p-md-5">
          <h4 class="fw-bold border-bottom pb-3 mb-4 text-primary-custom">About This Course</h4>
          <div class="course-description-content text-muted lh-lg fs-6">
            <?= nl2br(htmlspecialchars($course['course_description'])) ?>
          </div>
        </div>
      </div>

      <!-- Syllabus Accordion -->
      <?php if(!empty($syllabus_json)): ?>
      <div class="card shadow-sm border-0 rounded-6 mb-5">
        <div class="card-body p-4 p-md-5">
          <h4 class="fw-bold border-bottom pb-3 mb-4 text-primary-custom">Course Syllabus</h4>
          <div class="accordion accordion-borderless" id="syllabusAccordion">
            <?php foreach($syllabus_json as $index => $module): ?>
            <div class="accordion-item shadow-none rounded-4 mb-3 border bg-light bg-opacity-50">
              <h2 class="accordion-header" id="heading<?= $index ?>">
                <button class="accordion-button <?= $index !== 0 ? 'collapsed' : '' ?> fw-bold bg-transparent text-dark shadow-0 py-4" type="button" data-mdb-collapse-init data-mdb-target="#collapse<?= $index ?>" aria-expanded="<?= $index === 0 ? 'true' : 'false' ?>" aria-controls="collapse<?= $index ?>">
                  <i class="fas fa-book-open text-primary-custom me-3 opacity-50"></i> <?= htmlspecialchars($module['module_name']) ?>
                </button>
              </h2>
              <div id="collapse<?= $index ?>" class="accordion-collapse collapse <?= $index === 0 ? 'show' : '' ?>" aria-labelledby="heading<?= $index ?>" data-mdb-parent="#syllabusAccordion">
                <div class="accordion-body text-muted px-5 pb-4 pt-0">
                  <ul class="mb-0 ps-4 list-unstyled">
                    <?php 
                      $topics = explode(',', $module['topics']);
                      foreach($topics as $topic): 
                    ?>
                      <li class="mb-3 position-relative"><i class="fas fa-check-circle text-success position-absolute start-0 mt-1 ms-n4 opacity-75"></i> <?= htmlspecialchars(trim($topic)) ?></li>
                    <?php endforeach; ?>
                  </ul>
                </div>
              </div>
            </div>
            <?php endforeach; ?>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <!-- Reviews -->
      <div class="card shadow-sm border-0 rounded-6 mb-5" id="reviews">
        <div class="card-body p-4 p-md-5">
          <h4 class="fw-bold border-bottom pb-3 mb-4 text-primary-custom">Student Reviews</h4>
          
          <?php if(count($reviews) > 0): ?>
            <?php foreach($reviews as $review): ?>
            <div class="d-flex mb-4">
              <div class="avatar bg-primary-custom text-white rounded-circle d-flex align-items-center justify-content-center fw-bold me-3 shadow-sm" style="width: 50px; height: 50px; flex-shrink: 0;">
                <?= strtoupper(substr($review['reviewer_name'], 0, 1)) ?>
              </div>
              <div>
                <h6 class="fw-bold mb-1 border-0 bg-transparent"><?= htmlspecialchars($review['reviewer_name']) ?></h6>
                <div class="text-warning small mb-2">
                  <?php for($i=1; $i<=5; $i++): ?>
                    <i class="fa<?= $i <= $review['rating'] ? 's' : 'r' ?> fa-star"></i>
                  <?php endfor; ?>
                  <span class="text-muted ms-2 float-end" style="font-size: 0.8rem;"><?= date('M d, Y', strtotime($review['created_at'])) ?></span>
                </div>
                <?php if(!empty($review['title'])): ?>
                   <p class="fw-bold mb-1 small"><?= htmlspecialchars($review['title']) ?></p>
                <?php endif; ?>
                <p class="text-muted mb-0"><?= htmlspecialchars($review['review_text']) ?></p>
              </div>
            </div>
            <hr class="text-muted opacity-10">
            <?php endforeach; ?>
          <?php else: ?>
            <div class="text-center text-muted py-4">
              <i class="far fa-comment-dots fa-3x mb-3 opacity-50"></i>
              <p>No reviews yet. Be the first to review after completing!</p>
            </div>
          <?php endif; ?>
          
          <?php if($has_access): ?>
             <a href="#" class="btn btn-outline-primary btn-rounded mt-3">Write a Review</a>
          <?php endif; ?>

        </div>
      </div>

    </div>

    <!-- Right Sticky Sidebar -->
    <div class="col-lg-4">
      <div class="card shadow-lg border-0 rounded-6 sticky-top mb-5" style="top: 100px; z-index: 10;">
        <img src="<?= htmlspecialchars($course['course_image']) ?>" class="card-img-top d-none d-lg-block p-2 rounded-6" alt="Course" style="height: 240px; object-fit: cover;">
        <div class="card-body p-4 p-xl-5">
          
          <?php if($is_offer_active): ?>
              <div class="alert alert-danger py-3 px-3 text-center rounded-pill mb-4 fw-bold small shadow-sm animate-pulse border-0">
                  <i class="fas fa-clock fs-6 me-1"></i> Offer ends in <span id="countdownTimer" class="fs-6 text-dark ms-1"></span>
              </div>
              <script>
                // Simple countdown script
                const countDownDate = new Date("<?= date('M d, Y H:i:s', strtotime($course['offer_end_date'])) ?>").getTime();
                const x = setInterval(function() {
                  const now = new Date().getTime();
                  const distance = countDownDate - now;
                  if(distance < 0) {
                      clearInterval(x); document.getElementById("countdownTimer").innerHTML = "EXPIRED"; return;
                  }
                  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
                  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
                  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
                  document.getElementById("countdownTimer").innerHTML = days + "d " + hours + "h " + minutes + "m ";
                }, 1000);
              </script>
          <?php endif; ?>

          <div class="d-flex align-items-center mb-4 pb-3 border-bottom border-light">
             <h2 class="fw-bolder mb-0 text-success me-3 display-6">₹<?= number_format($display_price, 2) ?></h2>
             <?php if($is_offer_active && !empty($course['original_price'])): ?>
                <h5 class="text-muted text-decoration-line-through mb-0 fw-bold">₹<?= number_format($course['original_price'], 2) ?></h5>
             <?php endif; ?>
          </div>

          <ul class="list-unstyled text-muted fw-medium mb-5 ms-1">
            <li class="mb-3 d-flex align-items-center"><i class="fas fa-video text-primary-custom bg-light p-2 rounded-circle me-3"></i> <span>Accessible via Google Drive</span></li>
            <li class="mb-3 d-flex align-items-center"><i class="fas fa-infinity text-primary-custom bg-light p-2 rounded-circle me-3"></i> <span>Lifetime full access</span></li>
            <li class="mb-3 d-flex align-items-center"><i class="fas fa-mobile-alt text-primary-custom bg-light p-2 rounded-circle me-3" style="padding-left: 0.65rem !important; padding-right: 0.65rem !important;"></i> <span>Access on mobile and TV</span></li>
            <?php if($course['certificate_available'] === 'yes'): ?>
            <li class="mb-3 d-flex align-items-center"><i class="fas fa-trophy text-primary-custom bg-light p-2 rounded-circle me-3"></i> <span>Certificate of Completion</span></li>
            <?php endif; ?>
          </ul>
          
          <?php if($has_access): ?>
            <a href="dashboard/my-courses.php" class="btn btn-success btn-lg btn-rounded w-100 mb-3 shadow-sm py-3 fw-bold fs-6">Go to Dashboard</a>
          <?php else: ?>
            <button type="button" class="btn btn-action btn-lg btn-rounded w-100 mb-3 hover-lift shadow-md py-3 fw-bold fs-6" data-mdb-modal-init data-mdb-target="#checkoutModal">Enroll Now</button>
          <?php endif; ?>

          <div class="text-center mt-3">
             <a href="https://wa.me/1234567890?text=<?= urlencode('Enquiry about course: ' . $course['course_name']) ?>" class="text-success text-decoration-none fw-bold small"><i class="fab fa-whatsapp fs-5 me-1"></i> Have a question? Ask us</a>
          </div>

        </div>
      </div>
    </div>

  </div>
</div>

<!-- Checkout Modal -->
<div class="modal fade" id="checkoutModal" tabindex="-1" aria-labelledby="checkoutModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content rounded-6 shadow-md border-0">
      <div class="modal-header border-bottom-0 pb-0">
        <h5 class="modal-title fw-bold" id="checkoutModalLabel">Secure Checkout</h5>
        <button type="button" class="btn-close" data-mdb-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body p-4 pt-3">
        
        <div class="alert alert-danger d-none rounded-4 shadow-sm" id="checkoutError"></div>
        
        <form id="checkoutForm">
            <input type="hidden" id="checkoutCourseId" value="<?= $course['id'] ?>">
            
            <?php if(!isset($_SESSION['user_id'])): ?>
            <div class="bg-light p-3 rounded-5 border mb-4">
                <p class="small fw-bold text-muted mb-3"><i class="fas fa-info-circle me-1"></i> Guest Checkout (Creates an Account)</p>
                <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                    <input type="text" id="chkName" class="form-control form-control-lg" required />
                    <label class="form-label" for="chkName">Full Name *</label>
                </div>
                <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                    <input type="email" id="chkEmail" class="form-control form-control-lg" required />
                    <label class="form-label" for="chkEmail">Email Address *</label>
                </div>
                <div class="form-outline bg-white" data-mdb-input-init>
                    <input type="password" id="chkPass" class="form-control form-control-lg" placeholder="Optional" />
                    <label class="form-label" for="chkPass">Password (Optional)</label>
                </div>
                <small class="text-muted d-block mt-2" style="font-size:0.75rem;">If this email exists, please <a href="login.php">login first</a>. Otherwise, an account is created automatically.</small>
            </div>
            <?php else: ?>
                <div class="d-flex align-items-center mb-4 p-3 bg-light rounded-5 border">
                    <i class="fas fa-user-circle fa-2x text-primary-custom me-3"></i>
                    <div>
                        <div class="fw-bold mb-0 lh-1"><?= htmlspecialchars($_SESSION['name']) ?></div>
                        <small class="text-muted"><?= htmlspecialchars($_SESSION['email']) ?></small>
                    </div>
                </div>
            <?php endif; ?>
            
            <div class="d-flex justify-content-between align-items-center mb-4 pb-2 border-bottom">
                <span class="text-muted fw-bold">Total Payable:</span>
                <span class="fs-4 fw-bold text-success">₹<?= number_format($display_price, 2) ?></span>
            </div>

            <button type="submit" id="btnPayNow" class="btn btn-action btn-rounded w-100 py-3 shadow-sm hover-lift fw-bold fs-6">
                Pay Securely with Razorpay <i class="fas fa-arrow-right ms-2"></i>
            </button>
            <div class="text-center mt-3 opacity-50">
                <i class="fas fa-lock me-1"></i> <small>100% Encrypted Payment</small>
            </div>
        </form>
      </div>
    </div>
  </div>
</div>

<!-- Razorpay Script -->
<script src="https://checkout.razorpay.com/v1/checkout.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const checkoutForm = document.getElementById('checkoutForm');
    if(checkoutForm) {
        checkoutForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const btn = document.getElementById('btnPayNow');
            const errorDiv = document.getElementById('checkoutError');
            
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span> Processing...';
            btn.disabled = true;
            errorDiv.classList.add('d-none');
            
            const courseId = document.getElementById('checkoutCourseId').value;
            let reqData = new FormData();
            reqData.append('course_id', courseId);
            
            // Gather guest details if present
            const chkName = document.getElementById('chkName');
            const chkEmail = document.getElementById('chkEmail');
            const chkPass = document.getElementById('chkPass');
            
            let guestName = '', guestEmail = '', guestPass = '';
            
            if(chkName && chkEmail) {
                guestName = chkName.value.trim();
                guestEmail = chkEmail.value.trim();
                guestPass = chkPass ? chkPass.value : '';
            }

            // Step 1: Create Order
            fetch('api/create-order.php', {
                method: 'POST',
                body: reqData
            })
            .then(res => res.json())
            .then(data => {
                if(data.status === 'success') {
                    // Step 2: Open Razorpay Popup
                    var options = {
                        "key": data.key,
                        "amount": data.amount,
                        "currency": "INR",
                        "name": "DH ACADEMY",
                        "description": data.course_name,
                        "image": "https://cdn-icons-png.flaticon.com/512/3135/3135715.png",
                        "order_id": data.order_id,
                        "handler": function (response){
                            // Step 3: Verify Payment
                            btn.innerHTML = 'Verifying... Please wait.';
                            let verifyData = new FormData();
                            verifyData.append('razorpay_payment_id', response.razorpay_payment_id);
                            verifyData.append('razorpay_order_id', response.razorpay_order_id);
                            verifyData.append('razorpay_signature', response.razorpay_signature);
                            verifyData.append('course_id', courseId);
                            
                            // Essential for guest checkout payload to attach the payment
                            if(guestName && guestEmail) {
                                verifyData.append('student_name', guestName);
                                verifyData.append('student_email', guestEmail);
                                verifyData.append('student_password', guestPass);
                            }
                            
                            fetch('api/payment-verify.php', {
                                method: 'POST',
                                body: verifyData
                            })
                            .then(vRes => vRes.json())
                            .then(vData => {
                                if(vData.status === 'success') {
                                    window.location.href = vData.redirect + (vData.redirect.includes('?') ? '&' : '?') + 'msg=Payment Successful! Welcome to the course.';
                                } else {
                                    showError(vData.message || 'Verification Failed. Contact Support.');
                                }
                            })
                            .catch(err => showError('Verification Error: ' + err));
                        },
                        "prefill": {
                            "name": guestName || data.prefill_name,
                            "email": guestEmail || data.prefill_email,
                            "contact": data.prefill_phone
                        },
                        "theme": {
                            "color": "#0A2540"
                        },
                        "modal": {
                            "ondismiss": function() {
                                btn.innerHTML = 'Pay Securely with Razorpay <i class="fas fa-arrow-right ms-2"></i>';
                                btn.disabled = false;
                            }
                        }
                    };
                    var rzp1 = new Razorpay(options);
                    rzp1.on('payment.failed', function (response){
                        showError("Payment Failed: " + response.error.description);
                    });
                    rzp1.open();
                } else {
                    showError(data.message || 'Failed to initialize payment.');
                }
            })
            .catch(err => {
                showError('Network error. Try again.');
            });
            
            function showError(msg) {
                errorDiv.innerHTML = msg;
                errorDiv.classList.remove('d-none');
                btn.innerHTML = 'Pay Securely with Razorpay <i class="fas fa-arrow-right ms-2"></i>';
                btn.disabled = false;
            }
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>
