<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

$success = '';
$error = '';

// Handle issue action
if (isset($_POST['issue_cert'])) {
    $cert_id = (int)$_POST['cert_id'];
    $cert_link = trim($_POST['cert_link']);
    
    if (empty($cert_link) || !filter_var($cert_link, FILTER_VALIDATE_URL)) {
        $error = "A valid Google Drive link is required.";
    } else {
        $stmt = $pdo->prepare("UPDATE certificates SET status = 'issued', certificate_link = ?, issue_date = CURRENT_DATE WHERE id = ?");
        if ($stmt->execute([$cert_link, $cert_id])) {
            $success = "Certificate link issued successfully. Student can now download it.";
        } else {
            $error = "Failed to update certificate status.";
        }
    }
}

// Ensure every completed order has a pending cert entry if the course allows it and it doesn't already exist
$pdo->exec("
    INSERT INTO certificates (user_id, course_id, status)
    SELECT o.user_id, o.course_id, 'pending'
    FROM orders o
    JOIN courses c ON o.course_id = c.id
    LEFT JOIN certificates cr ON cr.user_id = o.user_id AND cr.course_id = o.course_id
    WHERE o.payment_status = 'success' 
    AND c.certificate_available = 'yes' 
    AND cr.id IS NULL
");

// Fetch active requests (Pending)
$stmt = $pdo->query("
    SELECT cr.*, u.name as student_name, u.email as student_email, u.phone as student_phone, c.course_name 
    FROM certificates cr
    JOIN users u ON cr.user_id = u.id
    JOIN courses c ON cr.course_id = c.id
    WHERE cr.status = 'pending'
    ORDER BY cr.created_at ASC
");
$pending_certs = $stmt->fetchAll();

// Fetch Issued
$issued_stmt = $pdo->query("
    SELECT cr.*, u.name as student_name, c.course_name 
    FROM certificates cr
    JOIN users u ON cr.user_id = u.id
    JOIN courses c ON cr.course_id = c.id
    WHERE cr.status = 'issued'
    ORDER BY cr.issue_date DESC LIMIT 50
");
$issued_certs = $issued_stmt->fetchAll();

$page_title = "Manage Certificates | Admin DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php"><i class="fas fa-shield-alt me-2"></i>DH Admin</a>
    <div class="ms-auto d-flex align-items-center">
        <span class="text-white me-3 d-none d-md-block">Logged in as <?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 rounded-top-5"><i class="fas fa-tachometer-alt me-3 text-muted"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-book me-3 text-muted"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-users me-3 text-muted"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-shopping-cart me-3 text-muted"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3 active border-0"><i class="fas fa-certificate me-3 text-white"></i>Certificates</a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-muted"></i>Analytics</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-4 rounded-6 shadow-sm border border-light">
                <h4 class="fw-bold mb-0 letter-spacing-1"><i class="fas fa-certificate text-primary-custom me-2"></i>Certificate Management</h4>
            </div>

            <?php if(!empty($success)): ?>
               <div class="alert alert-success alert-dismissible fade show rounded-4 shadow-sm" role="alert">
                    <i class="fas fa-check-circle me-2"></i> <?= htmlspecialchars($success) ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>
            <?php if(!empty($error)): ?>
               <div class="alert alert-danger alert-dismissible fade show rounded-4 shadow-sm" role="alert">
                    <i class="fas fa-exclamation-triangle me-2"></i> <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <!-- Pending Certificates -->
            <div class="card shadow-md border-0 rounded-6 mb-5 overflow-hidden">
                <div class="card-header bg-white py-4 border-bottom">
                    <h5 class="mb-0 fw-bold text-danger"><i class="fas fa-clock fs-5 me-2"></i> Action Required: Pending Issues (<?= count($pending_certs) ?>)</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="fw-bold text-muted text-uppercase small py-3 ps-4">Student</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3">Course</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3">Contact</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3 text-end pe-4">Issue Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($pending_certs) > 0): ?>
                                    <?php foreach($pending_certs as $cert): ?>
                                    <tr>
                                        <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($cert['student_name']) ?></td>
                                        <td class="text-truncate" style="max-width: 250px;"><?= htmlspecialchars($cert['course_name']) ?></td>
                                        <td>
                                            <div class="small">
                                                <div><i class="fas fa-envelope text-muted me-1"></i> <?= htmlspecialchars($cert['student_email']) ?></div>
                                                <?php if(!empty($cert['student_phone'])): ?>
                                                <div><i class="fab fa-whatsapp text-success me-1"></i> <a href="https://wa.me/91<?= $cert['student_phone'] ?>" target="_blank" class="text-dark"><?= htmlspecialchars($cert['student_phone']) ?></a></div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-end pe-4" style="width: 350px;">
                                            <form action="manage-certificates.php" method="POST" class="d-flex align-items-center gap-2 m-0 border rounded px-1 py-1 bg-light">
                                                <input type="hidden" name="cert_id" value="<?= $cert['id'] ?>">
                                                <input type="url" name="cert_link" class="form-control form-control-sm border-0 shadow-none bg-transparent" placeholder="Paste GDrive Drive link..." required style="min-width: 150px;">
                                                <button type="submit" name="issue_cert" class="btn btn-success btn-sm btn-rounded shadow-0 px-3 flex-shrink-0">Issue</button>
                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4" class="text-center py-5 text-muted">
                                            <i class="fas fa-check-circle fa-2x text-success mb-2 opacity-75"></i>
                                            <p class="mb-0">All clear! No pending certificate requests.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Recently Issued -->
            <div class="card shadow-sm border-0 rounded-6 mb-4 opacity-75 overflow-hidden">
                <div class="card-header bg-white py-4 border-bottom d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 fw-bold text-success"><i class="fas fa-award fs-5 me-2"></i> Recently Issued Certificates</h6>
                    <span class="badge bg-success rounded-pill"><?= count($issued_certs) ?> Issued</span>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0 small">
                            <thead class="bg-light">
                                <tr>
                                    <th class="fw-bold text-muted text-uppercase py-3 ps-4">Student</th>
                                    <th class="fw-bold text-muted text-uppercase py-3">Course</th>
                                    <th class="fw-bold text-muted text-uppercase py-3 text-center">Date Issued</th>
                                    <th class="fw-bold text-muted text-uppercase py-3 text-end pe-4">Link</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($issued_certs as $cert): ?>
                                <tr>
                                    <td class="ps-4 fw-bold text-dark"><?= htmlspecialchars($cert['student_name']) ?></td>
                                    <td class="text-truncate" style="max-width: 300px;"><?= htmlspecialchars($cert['course_name']) ?></td>
                                    <td class="text-center text-muted"><?= date('M d, Y', strtotime($cert['issue_date'])) ?></td>
                                    <td class="text-end pe-4">
                                        <a href="<?= htmlspecialchars($cert['certificate_link']) ?>" target="_blank" class="btn btn-sm btn-outline-primary btn-floating shadow-0"><i class="fas fa-external-link-alt"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
</body>
</html>
