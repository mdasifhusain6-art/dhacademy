<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

// Prepare graph data for the last 30 days of sales
$sales_data_stmt = $pdo->query("
    SELECT DATE(created_at) as sale_date, SUM(amount) as daily_revenue, COUNT(id) as daily_orders 
    FROM orders 
    WHERE payment_status = 'success' AND created_at >= DATE_SUB(CURRENT_DATE, INTERVAL 30 DAY)
    GROUP BY DATE(created_at)
    ORDER BY DATE(created_at) ASC
");
$sales_raw = $sales_data_stmt->fetchAll();

// Structure arrays for Chart.js
$dates = [];
$revenues = [];
$order_counts = [];

// Fill missing days with 0s for a smooth graph line
for ($i = 29; $i >= 0; $i--) {
    $date = date('Y-m-d', strtotime("-$i days"));
    $dates[] = date('M d', strtotime("-$i days")); // Shorter label format
    
    // Check if we have data for this date
    $revenue_val = 0;
    $count_val = 0;
    foreach ($sales_raw as $row) {
        if ($row['sale_date'] == $date) {
            $revenue_val = (float)$row['daily_revenue'];
            $count_val = (int)$row['daily_orders'];
            break;
        }
    }
    
    $revenues[] = $revenue_val;
    $order_counts[] = $count_val;
}

$page_title = "Analytics | Admin DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php"><i class="fas fa-shield-alt me-2"></i>DH Admin</a>
    <div class="ms-auto d-flex align-items-center">
        <span class="text-white me-3 d-none d-md-block">Logged in as <?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 rounded-top-5"><i class="fas fa-tachometer-alt me-3 text-muted"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-book me-3 text-muted"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-users me-3 text-muted"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-shopping-cart me-3 text-muted"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-certificate me-3 text-muted"></i>Certificates</a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 active border-0 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-white"></i>Analytics</a>
                </div>
            </div>
        </div>

        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="fw-bold mb-0">Sales Analytics (30 Days)</h3>
            </div>

            <!-- Chart Container -->
            <div class="card shadow-0 border rounded-6 mb-4">
                <div class="card-body p-4">
                    <canvas id="revenueChart" height="100"></canvas>
                </div>
            </div>

            <!-- Table Breakdown -->
            <div class="card shadow-0 border rounded-6 opacity-75">
                <div class="card-header bg-white py-3 border-bottom">
                    <h5 class="mb-0 fw-bold"><i class="fas fa-table text-muted me-2"></i> Tabular Breakdown</h5>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
                        <table class="table table-hover align-middle mb-0 text-center small">
                            <thead class="bg-light sticky-top">
                                <tr>
                                    <th class="fw-bold text-muted text-uppercase py-3">Date</th>
                                    <th class="fw-bold text-muted text-uppercase py-3">Orders Volume</th>
                                    <th class="fw-bold text-muted text-uppercase py-3">Daily Revenue (₹)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                    // Iterate backwards for the table (newest top)
                                    for($i = count($dates) - 1; $i >= 0; $i--): 
                                ?>
                                <tr>
                                    <td class="fw-bold text-dark"><?= $dates[$i] ?></td>
                                    <td><?= $order_counts[$i] ?></td>
                                    <td class="text-success fw-bold">₹<?= number_format($revenues[$i], 2) ?></td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
    const ctx = document.getElementById('revenueChart').getContext('2d');
    
    // Gradient for line chart
    const gradient = ctx.createLinearGradient(0, 0, 0, 400);
    gradient.addColorStop(0, 'rgba(10, 37, 64, 0.4)'); // Primary Custom Color
    gradient.addColorStop(1, 'rgba(10, 37, 64, 0.0)');

    const chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode($dates) ?>,
            datasets: [{
                label: 'Daily Revenue (₹)',
                data: <?= json_encode($revenues) ?>,
                borderColor: '#0A2540',
                backgroundColor: gradient,
                borderWidth: 3,
                pointBackgroundColor: '#FF6B00',
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointRadius: 4,
                pointHoverRadius: 6,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            if (context.parsed.y !== null) {
                                label += new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    }
                },
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(0,0,0,0.05)'
                    },
                    ticks: {
                        callback: function(value, index, values) {
                            return '₹' + value;
                        }
                    }
                }
            }
        }
    });
</script>
</body>
</html>
