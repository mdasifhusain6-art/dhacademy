<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

$success = '';
$error = '';

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage-courses.php");
    exit;
}

$course_id = (int)$_GET['id'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $course_name = trim($_POST['course_name']);
    $course_slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $course_name)));
    $course_category = trim($_POST['course_category']);
    $course_price = (float)$_POST['course_price'];
    $original_price = !empty($_POST['original_price']) ? (float)$_POST['original_price'] : null;
    $course_duration = trim($_POST['course_duration']);
    $course_level = trim($_POST['course_level']);
    $instructor_name = trim($_POST['instructor_name']);
    $course_image = trim($_POST['course_image']);
    $google_drive_link = trim($_POST['google_drive_link']);
    $certificate_available = isset($_POST['certificate_available']) ? 'yes' : 'no';
    
    // v2.0 fields
    $short_description = trim($_POST['short_description']);
    $course_description = trim($_POST['course_description']);
    $seo_title = trim($_POST['seo_title']);
    $seo_description = trim($_POST['seo_description']);
    $is_active = isset($_POST['is_active']) ? 'yes' : 'no';
    
    // Offer fields
    $offer_active = isset($_POST['offer_active']) ? 'yes' : 'no';
    $offer_end_date = !empty($_POST['offer_end_date']) ? $_POST['offer_end_date'] : null;
    $offer_label = trim($_POST['offer_label']);

    // Construct JSON for Syllabus
    $syllabus_arr = [];
    if (isset($_POST['module_name']) && is_array($_POST['module_name'])) {
        foreach ($_POST['module_name'] as $index => $module) {
            if (!empty($module)) {
                $topics = isset($_POST['module_topics'][$index]) ? trim($_POST['module_topics'][$index]) : '';
                $syllabus_arr[] = [
                    'module_name' => htmlspecialchars($module),
                    'topics' => htmlspecialchars($topics)
                ];
            }
        }
    }
    $syllabus_json = !empty($syllabus_arr) ? json_encode($syllabus_arr) : null;

    if (empty($course_name) || empty($course_price) || empty($google_drive_link)) {
        $error = "Name, Price, and Google Drive link are strictly required.";
    } else {
        // Enforce duplicate slug safely against other DB IDs
        $stmt_check = $pdo->prepare("SELECT id FROM courses WHERE course_slug = ? AND id != ?");
        $stmt_check->execute([$course_slug, $course_id]);
        if ($stmt_check->fetch()) {
            $course_slug = $course_slug . '-' . time();
        }

        $stmt = $pdo->prepare("
            UPDATE courses SET 
                course_name = ?, course_slug = ?, course_category = ?, course_price = ?, original_price = ?, 
                course_duration = ?, course_level = ?, instructor_name = ?, course_image = ?, google_drive_link = ?, 
                certificate_available = ?, short_description = ?, course_description = ?, seo_title = ?, seo_description = ?, 
                is_active = ?, offer_active = ?, offer_end_date = ?, offer_label = ?, syllabus = ?
            WHERE id = ?
        ");
        
        if ($stmt->execute([
            $course_name, $course_slug, $course_category, $course_price, $original_price, 
            $course_duration, $course_level, $instructor_name, $course_image, $google_drive_link, 
            $certificate_available, $short_description, $course_description, $seo_title, $seo_description, 
            $is_active, $offer_active, $offer_end_date, $offer_label, $syllabus_json, $course_id
        ])) {
            $success = "Course updated successfully.";
        } else {
            $error = "Error updating course.";
        }
    }
}

// Fetch current details
$stmt = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
$stmt->execute([$course_id]);
$course = $stmt->fetch();

if (!$course) {
    echo "Course not found.";
    exit;
}

// Decode syllabus
$syllabus = json_decode($course['syllabus'], true) ?? [];

$page_title = "Edit Course | Admin DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php"><i class="fas fa-shield-alt me-2"></i>DH Admin</a>
    <div class="ms-auto d-flex align-items-center">
        <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 rounded-top-5"><i class="fas fa-tachometer-alt me-3 text-muted"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3 border-0 active"><i class="fas fa-book me-3 text-white"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-users me-3 text-muted"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-shopping-cart me-3 text-muted"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-certificate me-3 text-muted"></i>Certificates</a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-muted"></i>Analytics</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-4 rounded-6 shadow-sm border border-light">
                <h4 class="fw-bold mb-0 letter-spacing-1"><i class="fas fa-edit text-primary-custom me-2"></i>Edit Course Catalog Entry</h4>
                <a href="manage-courses.php" class="btn btn-outline-dark btn-rounded shadow-0"><i class="fas fa-arrow-left me-2"></i> Back to Grid</a>
            </div>

            <?php if(!empty($success)): ?>
               <div class="alert alert-success rounded-4 shadow-sm"><i class="fas fa-check-circle me-2"></i> <?= $success ?></div>
            <?php endif; ?>
            <?php if(!empty($error)): ?>
               <div class="alert alert-danger rounded-4 shadow-sm"><i class="fas fa-exclamation-triangle me-2"></i> <?= $error ?></div>
            <?php endif; ?>

            <form action="edit-course.php?id=<?= $course_id ?>" method="POST" class="needs-validation">
                
                <div class="row g-4">
                    <!-- Core Details -->
                    <div class="col-lg-8">
                        <div class="card shadow-sm border-0 rounded-6 mb-4 overflow-hidden">
                            <div class="card-header bg-white py-4 border-bottom"><h5 class="mb-0 fw-bold letter-spacing-1">Core Details</h5></div>
                            <div class="card-body p-4 p-md-5">
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="text" id="course_name" name="course_name" class="form-control" value="<?= htmlspecialchars($course['course_name']) ?>" required />
                                    <label class="form-label" for="course_name">Course Title *</label>
                                </div>
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <textarea class="form-control" id="short_description" name="short_description" rows="2" maxlength="300"><?= htmlspecialchars($course['short_description']) ?></textarea>
                                    <label class="form-label" for="short_description">Short Description (Max 300 chars)</label>
                                </div>
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <textarea class="form-control" id="course_description" name="course_description" rows="6"><?= htmlspecialchars($course['course_description']) ?></textarea>
                                    <label class="form-label" for="course_description">Full Detailed Description</label>
                                </div>
                                <div class="row">
                                    <div class="col-md-6 mb-4">
                                        <select class="form-select" name="course_category" required>
                                            <option value="Technical" <?= $course['course_category'] == 'Technical' ? 'selected' : '' ?>>Technical</option>
                                            <option value="Non-Technical" <?= $course['course_category'] == 'Non-Technical' ? 'selected' : '' ?>>Non-Technical</option>
                                            <option value="Accounting" <?= $course['course_category'] == 'Accounting' ? 'selected' : '' ?>>Accounting</option>
                                            <option value="Marketing" <?= $course['course_category'] == 'Marketing' ? 'selected' : '' ?>>Marketing</option>
                                            <option value="Design" <?= $course['course_category'] == 'Design' ? 'selected' : '' ?>>Design</option>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-4">
                                        <div class="form-outline" data-mdb-input-init>
                                            <input type="url" id="course_image" name="course_image" class="form-control" value="<?= htmlspecialchars($course['course_image']) ?>" />
                                            <label class="form-label" for="course_image">Thumbnail Image URL</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Syllabus Builder -->
                        <div class="card shadow-sm border-0 rounded-6 mb-4 overflow-hidden">
                            <div class="card-header bg-white py-4 border-bottom d-flex justify-content-between align-items-center">
                                <h5 class="mb-0 fw-bold">Syllabus Builder (JSON)</h5>
                                <button type="button" class="btn btn-sm btn-outline-primary shadow-0" onclick="addModule()">Add Module</button>
                            </div>
                            <div class="card-body p-4" id="syllabusContainer">
                                
                                <?php if(empty($syllabus)): ?>
                                <div class="syllabus-module border rounded p-3 mb-3 bg-light position-relative">
                                    <button type="button" class="btn-close position-absolute top-0 end-0 m-2" aria-label="Close" onclick="this.parentElement.remove()"></button>
                                    <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                                        <input type="text" name="module_name[]" class="form-control" />
                                        <label class="form-label">Module Title</label>
                                    </div>
                                    <div class="form-outline bg-white" data-mdb-input-init>
                                        <textarea class="form-control" name="module_topics[]" rows="2"></textarea>
                                        <label class="form-label">Topics (Comma separated)</label>
                                    </div>
                                </div>
                                <?php else: ?>
                                    <?php foreach($syllabus as $module): ?>
                                    <div class="syllabus-module border rounded p-3 mb-3 bg-light position-relative">
                                        <button type="button" class="btn-close position-absolute top-0 end-0 m-2" aria-label="Close" onclick="this.parentElement.remove()"></button>
                                        <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                                            <input type="text" name="module_name[]" class="form-control active" value="<?= htmlspecialchars($module['module_name']) ?>" />
                                        </div>
                                        <div class="form-outline bg-white" data-mdb-input-init>
                                            <textarea class="form-control active" name="module_topics[]" rows="2"><?= htmlspecialchars($module['topics']) ?></textarea>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Side Options -->
                    <div class="col-lg-4">
                        
                        <div class="card shadow-sm border-0 rounded-6 mb-4 overflow-hidden">
                            <div class="card-header bg-white py-4 border-bottom"><h5 class="mb-0 fw-bold letter-spacing-1">Pricing & Access</h5></div>
                            <div class="card-body p-4">
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="number" step="0.01" id="course_price" name="course_price" class="form-control" value="<?= $course['course_price'] ?>" required />
                                    <label class="form-label" for="course_price">Selling Price (₹) *</label>
                                </div>
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="number" step="0.01" id="original_price" name="original_price" class="form-control" value="<?= $course['original_price'] ?>" />
                                    <label class="form-label" for="original_price">Original Price (Strike-through)</label>
                                </div>
                                <div class="form-outline mb-4 bg-light" data-mdb-input-init>
                                    <input type="url" id="google_drive_link" name="google_drive_link" class="form-control" value="<?= htmlspecialchars($course['google_drive_link']) ?>" required />
                                    <label class="form-label" for="google_drive_link">Google Drive Link *</label>
                                </div>
                            </div>
                        </div>

                        <!-- Meta Details -->
                        <div class="card shadow-sm border-0 rounded-6 mb-4 overflow-hidden">
                            <div class="card-header bg-white py-4 border-bottom"><h5 class="mb-0 fw-bold letter-spacing-1">Meta Details</h5></div>
                            <div class="card-body p-4">
                                <div class="row g-3 mb-4">
                                    <div class="col-6">
                                        <div class="form-outline" data-mdb-input-init>
                                            <input type="text" id="course_duration" name="course_duration" class="form-control" value="<?= htmlspecialchars($course['course_duration']) ?>" />
                                            <label class="form-label" for="course_duration">Duration (e.g. 10 Hours)</label>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <select class="form-select" name="course_level">
                                            <option value="Beginner" <?= $course['course_level'] == 'Beginner' ? 'selected' : '' ?>>Beginner</option>
                                            <option value="Intermediate" <?= $course['course_level'] == 'Intermediate' ? 'selected' : '' ?>>Intermediate</option>
                                            <option value="Advanced" <?= $course['course_level'] == 'Advanced' ? 'selected' : '' ?>>Advanced</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-outline mb-4" data-mdb-input-init>
                                    <input type="text" id="instructor_name" name="instructor_name" class="form-control" value="<?= htmlspecialchars($course['instructor_name']) ?>" />
                                    <label class="form-label" for="instructor_name">Instructor Name</label>
                                </div>
                            </div>
                        </div>
                        
                         <!-- SEO & Toggles -->
                        <div class="card shadow-sm border-0 rounded-6 mb-4">
                            <div class="card-body p-4 p-md-5 bg-light rounded-6 border border-light">
                                <h6 class="fw-bold mb-3">Settings & SEO</h6>
                                
                                <div class="form-check form-switch mb-3">
                                  <input class="form-check-input" type="checkbox" id="is_active" name="is_active" <?= $course['is_active'] == 'yes' ? 'checked' : '' ?>>
                                  <label class="form-check-label fw-bold" for="is_active">Publish Course</label>
                                </div>
                                
                                <div class="form-check form-switch mb-4">
                                  <input class="form-check-input" type="checkbox" id="certificate_available" name="certificate_available" <?= $course['certificate_available'] == 'yes' ? 'checked' : '' ?>>
                                  <label class="form-check-label" for="certificate_available">Provide DH Academy Certificate</label>
                                </div>

                                <div class="form-check form-switch mb-3 mt-3 border-top pt-3">
                                  <input class="form-check-input" type="checkbox" id="offer_active" name="offer_active" <?= $course['offer_active'] == 'yes' ? 'checked' : '' ?>>
                                  <label class="form-check-label text-danger fw-bold" for="offer_active">Enable Special Offer Timer</label>
                                </div>
                                <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                                    <?php
                                        // Format date for datetime-local input safely
                                        $offerDate = !empty($course['offer_end_date']) ? date('Y-m-d\TH:i', strtotime($course['offer_end_date'])) : '';
                                    ?>
                                    <input type="datetime-local" id="offer_end_date" name="offer_end_date" class="form-control" value="<?= $offerDate ?>" />
                                    <label class="form-label" for="offer_end_date">Offer End Date/Time</label>
                                </div>
                                <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                                    <input type="text" id="offer_label" name="offer_label" class="form-control active" value="<?= htmlspecialchars($course['offer_label']) ?>" />
                                </div>
                                
                                <hr class="my-4">
                                
                                <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                                    <input type="text" id="seo_title" name="seo_title" class="form-control active" value="<?= htmlspecialchars($course['seo_title']) ?>" />
                                </div>
                                <div class="form-outline mb-3 bg-white" data-mdb-input-init>
                                    <textarea class="form-control active" id="seo_description" name="seo_description" rows="2"><?= htmlspecialchars($course['seo_description']) ?></textarea>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary btn-lg btn-block btn-rounded shadow-1-strong py-3 hover-lift"><i class="fas fa-save me-2"></i> Update Course Node</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
<script>
function addModule() {
    const container = document.getElementById('syllabusContainer');
    const html = `
    <div class="syllabus-module border rounded p-3 mb-3 bg-light position-relative">
        <button type="button" class="btn-close position-absolute top-0 end-0 m-2" aria-label="Close" onclick="this.parentElement.remove()"></button>
        <div class="form-outline mb-3 bg-white" data-mdb-input-init>
            <input type="text" name="module_name[]" class="form-control" />
            <label class="form-label">Module Title</label>
        </div>
        <div class="form-outline bg-white" data-mdb-input-init>
            <textarea class="form-control" name="module_topics[]" rows="2"></textarea>
            <label class="form-label">Topics (Comma separated)</label>
        </div>
    </div>`;
    container.insertAdjacentHTML('beforeend', html);
    document.querySelectorAll('.form-outline').forEach((formOutline) => {
      new mdb.Input(formOutline).init();
    });
}
</script>
</body>
</html>
