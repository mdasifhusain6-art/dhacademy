<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

// Handle delete operation securely
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $delete_id = $_GET['delete'];
    
    // Instead of full delete, soft delete or check orders first (to avoid breaking constraints)
    // Actually we will full delete for parity if no orders, otherwise softly mark offline.
    $check_orders = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE course_id = ?");
    $check_orders->execute([$delete_id]);
    if ($check_orders->fetchColumn() > 0) {
        // Soft delete
        $del_stmt = $pdo->prepare("UPDATE courses SET is_active = 'no' WHERE id = ?");
        $del_stmt->execute([$delete_id]);
        $msg = "Course has orders associated. It has been taken offline instead of deleted entirely.";
    } else {
        // Hard delete
        $del_stmt = $pdo->prepare("DELETE FROM courses WHERE id = ?");
        $del_stmt->execute([$delete_id]);
        $msg = "Course deleted completely.";
    }
    
    header("Location: manage-courses.php?msg=" . urlencode($msg));
    exit;
}

// Fetch all courses with basic stats
$stmt = $pdo->query("
    SELECT c.*, 
    (SELECT COUNT(*) FROM orders o WHERE o.course_id = c.id AND o.payment_status = 'success') as total_sales,
    (SELECT COALESCE(SUM(amount), 0) FROM orders o WHERE o.course_id = c.id AND o.payment_status = 'success') as total_revenue
    FROM courses c 
    ORDER BY c.created_at DESC
");
$courses = $stmt->fetchAll();

$page_title = "Manage Courses | Admin DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php"><i class="fas fa-shield-alt me-2"></i>DH Admin</a>
    <div class="ms-auto d-flex align-items-center">
        <span class="text-white me-3 d-none d-md-block">Logged in as <?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 rounded-top-5"><i class="fas fa-tachometer-alt me-3 text-muted"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3 active border-0"><i class="fas fa-book me-3 text-white"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-users me-3 text-muted"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-shopping-cart me-3 text-muted"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-certificate me-3 text-muted"></i>Certificates</a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-muted"></i>Analytics</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-4 rounded-6 shadow-sm border border-light">
                <h4 class="fw-bold mb-0 letter-spacing-1"><i class="fas fa-book text-primary-custom me-2"></i>Course Master Grid</h4>
                <a href="add-course.php" class="btn btn-action shadow-md btn-rounded hover-lift px-4"><i class="fas fa-plus me-2"></i> Create New</a>
            </div>

            <?php if(isset($_GET['msg'])): ?>
               <div class="alert alert-info alert-dismissible fade show rounded-4 shadow-sm" role="alert">
                    <i class="fas fa-info-circle me-2"></i> <?= htmlspecialchars($_GET['msg']) ?>
                    <button type="button" class="btn-close" data-mdb-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden">
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light text-muted small text-uppercase">
                                <tr>
                                    <th class="ps-4 py-3 fw-bold">Course Details</th>
                                    <th class="py-3 fw-bold">Price Status</th>
                                    <th class="py-3 text-center fw-bold">Total Sales</th>
                                    <th class="py-3 text-end fw-bold">Revenue</th>
                                    <th class="py-3 text-center fw-bold pe-4">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($courses) > 0): ?>
                                    <?php foreach($courses as $course): ?>
                                    <tr>
                                        <td class="ps-4">
                                            <div class="d-flex align-items-center gap-3">
                                                <img src="<?= htmlspecialchars($course['course_image']) ?>" alt="" class="rounded-4 object-fit-cover shadow-sm" style="width: 60px; height: 60px;">
                                                <div>
                                                    <div class="fw-bold text-dark mb-1 text-truncate" style="max-width: 300px;"><?= htmlspecialchars($course['course_name']) ?></div>
                                                    <span class="badge <?= $course['is_active'] === 'yes' ? 'bg-success' : 'bg-danger' ?> rounded-pill small">
                                                        <?= $course['is_active'] === 'yes' ? 'Active Published' : 'Offline Mode' ?>
                                                    </span>
                                                    <span class="badge bg-light text-dark border ms-1 rounded-pill"><?= htmlspecialchars($course['course_category']) ?></span>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="fw-bold fs-6">₹<?= number_format($course['course_price'], 2) ?></div>
                                            <?php if($course['original_price'] > $course['course_price']): ?>
                                                <div class="text-muted small text-decoration-line-through">₹<?= number_format($course['original_price'], 2) ?></div>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-center fw-bold text-dark fs-5"><?= $course['total_sales'] ?></td>
                                        <td class="text-end fw-bold text-success">₹<?= number_format($course['total_revenue'], 2) ?></td>
                                        <td class="text-center pe-4">
                                            <!-- Setup link to course editing -->
                                            <a href="edit-course.php?id=<?= $course['id'] ?>" class="btn btn-sm btn-primary btn-floating shadow-0 me-2" title="Edit Course"><i class="fas fa-edit"></i></a>
                                            <button type="button" class="btn btn-sm btn-danger btn-floating shadow-0" title="Delete Course" onclick="confirmDelete(<?= $course['id'] ?>)">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fas fa-box-open fa-2x mb-2 opacity-50"></i>
                                            <p class="mb-0">No courses defined yet.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
<script>
function confirmDelete(id) {
    if(confirm('Are you certain you want to delete this course? If there are active orders, it will be marked Offline instead to protect user data.')) {
        window.location.href = 'manage-courses.php?delete=' + id;
    }
}
</script>
</body>
</html>
