<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

// Get counts
$students = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$courses = $pdo->query("SELECT COUNT(*) FROM courses WHERE is_active = 'yes'")->fetchColumn();
$orders = $pdo->query("SELECT COUNT(*) FROM orders WHERE payment_status = 'success'")->fetchColumn();
$revenue = $pdo->query("SELECT SUM(amount) FROM orders WHERE payment_status = 'success'")->fetchColumn();
$pending_certs = $pdo->query("SELECT COUNT(*) FROM certificates WHERE status = 'pending'")->fetchColumn();

// Fetch recent active orders
$recent_orders = $pdo->query("
    SELECT o.*, u.name as student_name, c.course_name 
    FROM orders o
    JOIN users u ON o.user_id = u.id
    JOIN courses c ON o.course_id = c.id
    WHERE o.payment_status = 'success'
    ORDER BY o.created_at DESC LIMIT 5
")->fetchAll();

$page_title = "Admin Dashboard | DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php">
        <i class="fas fa-shield-alt me-2"></i>DH Admin
    </a>
    
    <button class="navbar-toggler" type="button" data-mdb-collapse-init data-mdb-target="#adminNav" aria-controls="adminNav" aria-expanded="false" aria-label="Toggle navigation">
      <i class="fas fa-bars"></i>
    </button>
    
    <div class="collapse navbar-collapse" id="adminNav">
      <ul class="navbar-nav ms-auto mb-2 mb-lg-0 align-items-center">
        <?php if($pending_certs > 0): ?>
            <li class="nav-item me-3">
                <a class="nav-link text-danger fw-bold" href="manage-certificates.php"><i class="fas fa-bell me-1 anim-spin"></i> <?= $pending_certs ?> Cert Requests</a>
            </li>
        <?php endif; ?>
        <li class="nav-item">
            <span class="navbar-text text-white me-3">Logged in as <?= htmlspecialchars($_SESSION['name']) ?></span>
        </li>
        <li class="nav-item">
            <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
        </li>
      </ul>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 active rounded-top-5 border-0"><i class="fas fa-tachometer-alt me-3"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-book me-3 text-muted"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-users me-3 text-muted"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-shopping-cart me-3 text-muted"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3 d-flex justify-content-between align-items-center">
                        <div><i class="fas fa-certificate me-3 text-muted"></i>Certificates</div>
                        <?php if($pending_certs > 0): ?><span class="badge bg-danger rounded-pill"><?= $pending_certs ?></span><?php endif; ?>
                    </a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-muted"></i>Analytics</a>
                </div>
            </div>
        </div>

        <!-- Main Content Core -->
        <div class="col-lg-10">
            
            <!-- Quick Stats -->
            <div class="row g-4 mb-5">
                <div class="col-md-3">
                    <div class="card border-0 rounded-6 overflow-hidden position-relative hover-lift shadow-md" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%);">
                        <div class="position-absolute end-0 bottom-0 opacity-10" style="transform: translate(20%, 20%);"><i class="fas fa-rupee-sign" style="font-size: 6rem; color: white;"></i></div>
                        <div class="card-body p-4 position-relative z-1">
                            <i class="fas fa-rupee-sign fa-2x text-white mb-3 shadow-sm bg-white bg-opacity-25 p-2 rounded-circle"></i>
                            <h2 class="fw-bolder mb-1 text-white">₹<?= number_format($revenue ?? 0, 2) ?></h2>
                            <p class="mb-0 small text-uppercase fw-bold opacity-90 text-white letter-spacing-1">Total Revenue</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-success text-white shadow-md border-0 rounded-6 overflow-hidden position-relative hover-lift">
                        <div class="position-absolute end-0 bottom-0 opacity-10" style="transform: translate(20%, 20%);"><i class="fas fa-users" style="font-size: 6rem; color: white;"></i></div>
                        <div class="card-body p-4 position-relative z-1">
                            <i class="fas fa-users fa-2x text-white mb-3 shadow-sm bg-white bg-opacity-25 p-2 rounded-circle"></i>
                            <h2 class="fw-bolder mb-1 text-white"><?= $students ?></h2>
                            <p class="mb-0 small text-uppercase fw-bold opacity-90 text-white letter-spacing-1">Students</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card shadow-md border-0 rounded-6 overflow-hidden position-relative hover-lift" style="background: linear-gradient(135deg, #FF6B00 0%, #ff8c33 100%);">
                        <div class="position-absolute end-0 bottom-0 opacity-20" style="transform: translate(20%, 20%);"><i class="fas fa-book" style="font-size: 6rem; color: white;"></i></div>
                        <div class="card-body p-4 position-relative z-1">
                            <i class="fas fa-book fa-2x text-white mb-3 shadow-sm bg-white bg-opacity-25 p-2 rounded-circle text-dark"></i>
                            <h2 class="fw-bolder mb-1 text-white"><?= $courses ?></h2>
                            <p class="mb-0 small text-uppercase fw-bold opacity-90 text-white letter-spacing-1">Active Courses</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card bg-info text-white shadow-md border-0 rounded-6 overflow-hidden position-relative hover-lift">
                        <div class="position-absolute end-0 bottom-0 opacity-10" style="transform: translate(20%, 20%);"><i class="fas fa-shopping-cart" style="font-size: 6rem; color: white;"></i></div>
                        <div class="card-body p-4 position-relative z-1">
                            <i class="fas fa-shopping-cart fa-2x text-white mb-3 shadow-sm bg-white bg-opacity-25 p-2 rounded-circle"></i>
                            <h2 class="fw-bolder mb-1 text-white"><?= $orders ?></h2>
                            <p class="mb-0 small text-uppercase fw-bold opacity-90 text-white letter-spacing-1">Successful Sales</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Orders Data Table -->
            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden">
                <div class="card-header bg-white py-4 border-bottom d-flex justify-content-between align-items-center">
                    <h5 class="mb-0 fw-bold letter-spacing-1"><i class="fas fa-history text-primary-custom me-2"></i> Recent Successful Orders</h5>
                    <a href="manage-orders.php" class="btn btn-sm btn-outline-primary btn-rounded shadow-0">View All</a>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="bg-light">
                                <tr>
                                    <th class="fw-bold text-muted text-uppercase small py-3 ps-4">Transaction ID</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3">Student</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3">Course</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3 text-end">Amount</th>
                                    <th class="fw-bold text-muted text-uppercase small py-3 text-center">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($recent_orders) > 0): ?>
                                    <?php foreach($recent_orders as $order): ?>
                                    <tr>
                                        <td class="ps-4"><span class="badge bg-light text-dark border font-monospace"><?= htmlspecialchars($order['razorpay_payment_id']) ?></span></td>
                                        <td class="fw-bold text-dark"><?= htmlspecialchars($order['student_name']) ?></td>
                                        <td class="text-truncate" style="max-width: 250px;"><?= htmlspecialchars($order['course_name']) ?></td>
                                        <td class="text-end fw-bold text-success">₹<?= number_format($order['amount'], 2) ?></td>
                                        <td class="text-center text-muted small"><?= date('M d, Y', strtotime($order['created_at'])) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fas fa-box-open fa-2x mb-2 opacity-50"></i>
                                            <p class="mb-0">No active orders yet.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
</body>
</html>
