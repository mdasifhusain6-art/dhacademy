<?php
session_start();
require_once '../config/database.php';

if (isset($_SESSION['user_id']) && $_SESSION['role'] === 'admin') {
    header("Location: dashboard.php");
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin' AND is_active = 1");
    $stmt->execute([$email]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $admin['id'];
        $_SESSION['name'] = $admin['name'];
        $_SESSION['email'] = $admin['email'];
        $_SESSION['role'] = $admin['role'];
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Invalid admin credentials or account disabled.";
    }
}

$page_title = "Admin Portal | DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        body { background: #f4f7fa; }
    </style>
</head>
<body class="d-flex align-items-center justify-content-center vh-100">

<div class="container text-center max-width-500">
    <div class="mb-4">
        <i class="fas fa-graduation-cap fa-3x text-warning mb-2"></i>
        <h3 class="fw-bold text-primary-custom">DH ACADEMY <span class="text-danger small">ADMIN</span></h3>
    </div>
    
    <div class="card shadow-4-strong border-0 rounded-5 text-start">
        <div class="card-body p-4 p-md-5">
            <h5 class="fw-bold mb-4 text-center">Secure Portal Access</h5>
            
            <?php if(!empty($error)): ?>
                <div class="alert alert-danger rounded-4 py-2 small fw-bold text-center"><i class="fas fa-shield-alt me-1"></i> <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form action="index.php" method="POST">
                <div class="form-outline mb-4" data-mdb-input-init>
                    <input type="email" id="email" name="email" class="form-control form-control-lg" required />
                    <label class="form-label" for="email">Admin Email</label>
                </div>
                
                <div class="form-outline mb-4" data-mdb-input-init>
                    <input type="password" id="password" name="password" class="form-control form-control-lg" required />
                    <label class="form-label" for="password">Security Key</label>
                </div>
                
                <button type="submit" class="btn btn-action btn-lg btn-block btn-rounded shadow-1-strong hover-lift mt-4"><i class="fas fa-sign-in-alt me-2"></i>Authenticate</button>
            </form>
        </div>
    </div>
    
    <div class="mt-4 text-muted small">
        <p>&copy; <?= date('Y') ?> DH ACADEMY System. All rights reserved.</p>
    </div>
</div>

<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
</body>
</html>
