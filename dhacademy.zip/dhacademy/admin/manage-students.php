<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

// Prepare data maps
$stmt = $pdo->query("
    SELECT u.*, 
    (SELECT COUNT(*) FROM orders o WHERE o.user_id = u.id AND o.payment_status = 'success') as purchased_courses,
    (SELECT COALESCE(SUM(amount), 0) FROM orders o WHERE o.user_id = u.id AND o.payment_status = 'success') as total_spend
    FROM users u 
    WHERE u.role = 'student'
    ORDER BY u.created_at DESC
");
$students = $stmt->fetchAll();

$page_title = "Manage Students | Admin DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php"><i class="fas fa-shield-alt me-2"></i>DH Admin</a>
    <div class="ms-auto d-flex align-items-center">
        <span class="text-white me-3 d-none d-md-block">Logged in as <?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 rounded-top-5"><i class="fas fa-tachometer-alt me-3 text-muted"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-book me-3 text-muted"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3 active border-0"><i class="fas fa-users me-3 text-white"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-shopping-cart me-3 text-muted"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-certificate me-3 text-muted"></i>Certificates</a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-muted"></i>Analytics</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-4 rounded-6 shadow-sm border border-light">
                <h4 class="fw-bold mb-0 letter-spacing-1"><i class="fas fa-users text-primary-custom me-2"></i>Student Roster</h4>
                <span class="badge bg-primary-custom rounded-pill p-2 fs-6 shadow-md"><?= count($students) ?> Total Accounts</span>
            </div>

            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden">
                <!-- Search input for UX -->
                <div class="card-header bg-white py-4 border-bottom">
                    <div class="form-outline" data-mdb-input-init style="max-width:300px;">
                        <input type="text" id="searchInput" class="form-control" />
                        <label class="form-label" for="searchInput"><i class="fas fa-search me-1"></i> Search Students...</label>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="studentTable">
                            <thead class="bg-light text-muted small text-uppercase">
                                <tr>
                                    <th class="ps-4 py-3 fw-bold">Student Name</th>
                                    <th class="py-3 fw-bold">Contact Info</th>
                                    <th class="py-3 text-center fw-bold">Registered On</th>
                                    <th class="py-3 text-center fw-bold">Purchased</th>
                                    <th class="py-3 text-end fw-bold pe-4">LTV (Spend)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($students) > 0): ?>
                                    <?php foreach($students as $user): ?>
                                    <tr class="student-row">
                                        <td class="ps-4">
                                            <div class="fw-bold text-dark mb-1 student-name"><?= htmlspecialchars($user['name']) ?></div>
                                            <!-- Simple active/inactive check -->
                                            <span class="badge <?= $user['is_active'] ? 'bg-success' : 'bg-danger' ?> rounded-pill small">
                                                <?= $user['is_active'] ? 'Active' : 'Banned' ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="small">
                                                <div class="student-email"><i class="fas fa-envelope text-muted me-2"></i> <?= htmlspecialchars($user['email']) ?></div>
                                                <?php if(!empty($user['phone'])): ?>
                                                    <div class="mt-1"><i class="fas fa-phone text-muted me-2"></i> <?= htmlspecialchars($user['phone']) ?></div>
                                                <?php endif; ?>
                                            </div>
                                        </td>
                                        <td class="text-center text-muted"><?= date('M d, Y', strtotime($user['created_at'])) ?></td>
                                        <td class="text-center fw-bold text-dark fs-6"><?= $user['purchased_courses'] ?></td>
                                        <td class="text-end fw-bold text-success pe-4">₹<?= number_format($user['total_spend'], 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fas fa-users-slash fa-2x mb-2 opacity-50"></i>
                                            <p class="mb-0">No students registered yet.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
<script>
    // Simple table search filter
    document.getElementById('searchInput').addEventListener('keyup', function() {
        let text = this.value.toLowerCase();
        let rows = document.querySelectorAll('.student-row');
        rows.forEach(function(row) {
            let name = row.querySelector('.student-name').textContent.toLowerCase();
            let email = row.querySelector('.student-email').textContent.toLowerCase();
            if(name.indexOf(text) > -1 || email.indexOf(text) > -1) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
</script>
</body>
</html>
