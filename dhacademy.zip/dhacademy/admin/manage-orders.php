<?php
require_once '../includes/admin-auth-check.php';
require_once '../config/database.php';

// Prepare data maps
$stmt = $pdo->query("
    SELECT o.*, u.name as student_name, u.email as student_email, c.course_name 
    FROM orders o 
    JOIN users u ON o.user_id = u.id
    JOIN courses c ON o.course_id = c.id
    ORDER BY o.created_at DESC
");
$orders = $stmt->fetchAll();

$page_title = "Manage Orders | Admin DH ACADEMY";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <!-- MDB & Fonts -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet" />
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark sticky-top">
  <div class="container-fluid px-4">
    <a class="navbar-brand fw-bold text-warning" href="dashboard.php"><i class="fas fa-shield-alt me-2"></i>DH Admin</a>
    <div class="ms-auto d-flex align-items-center">
        <span class="text-white me-3 d-none d-md-block">Logged in as <?= htmlspecialchars($_SESSION['name']) ?></span>
        <a href="../logout.php" class="btn btn-outline-light btn-sm btn-rounded">Logout</a>
    </div>
  </div>
</nav>

<div class="container-fluid py-4 px-4">
    <div class="row g-4">
        
        <!-- Sidebar Navigation -->
        <div class="col-lg-2">
            <div class="card shadow-0 border rounded-5 mb-4 border-0">
                <div class="list-group list-group-flush rounded-5 font-weight-bold">
                    <a href="dashboard.php" class="list-group-item list-group-item-action py-3 rounded-top-5"><i class="fas fa-tachometer-alt me-3 text-muted"></i>Dashboard</a>
                    <a href="add-course.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-plus-circle me-3 text-muted"></i>Add Course</a>
                    <a href="manage-courses.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-book me-3 text-muted"></i>Manage Courses</a>
                    <a href="manage-students.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-users me-3 text-muted"></i>Students</a>
                    <a href="manage-orders.php" class="list-group-item list-group-item-action py-3 active border-0"><i class="fas fa-shopping-cart me-3 text-white"></i>Orders</a>
                    <a href="manage-certificates.php" class="list-group-item list-group-item-action py-3"><i class="fas fa-certificate me-3 text-muted"></i>Certificates</a>
                    <a href="analytics.php" class="list-group-item list-group-item-action py-3 rounded-bottom-5"><i class="fas fa-chart-line me-3 text-muted"></i>Analytics</a>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-lg-10">
            <div class="d-flex justify-content-between align-items-center mb-4 bg-white p-4 rounded-6 shadow-sm border border-light">
                <h4 class="fw-bold mb-0 letter-spacing-1"><i class="fas fa-shopping-cart text-primary-custom me-2"></i>Sales & Checkout History</h4>
            </div>

            <div class="card shadow-md border-0 rounded-6 mb-4 overflow-hidden">
                <div class="card-header bg-white py-4 border-bottom d-flex justify-content-between align-items-center">
                    <div class="form-outline" data-mdb-input-init style="max-width:300px;">
                        <input type="text" id="searchInput" class="form-control mb-0" />
                        <label class="form-label" for="searchInput"><i class="fas fa-search me-1"></i> Search Order/Student...</label>
                    </div>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0" id="orderTable">
                            <thead class="bg-light text-muted small text-uppercase">
                                <tr>
                                    <th class="ps-4 py-3 fw-bold">Order Tracking IDs</th>
                                    <th class="py-3 fw-bold">Student</th>
                                    <th class="py-3 fw-bold">Course Item</th>
                                    <th class="py-3 text-center fw-bold">Checkout Status</th>
                                    <th class="py-3 text-end fw-bold pe-4">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($orders) > 0): ?>
                                    <?php foreach($orders as $order): ?>
                                    <tr class="order-row">
                                        <td class="ps-4">
                                            <div class="fw-bold text-dark font-monospace mb-1 order-id"><?= htmlspecialchars($order['razorpay_payment_id'] ?? 'SYS_INIT') ?></div>
                                            <div class="small text-muted"><i class="fas fa-calendar-alt me-1"></i> <?= date('M d, Y', strtotime($order['created_at'])) ?></div>
                                            <div class="small text-muted font-monospace"><i class="fas fa-receipt me-1"></i> <?= htmlspecialchars($order['razorpay_order_id']) ?></div>
                                        </td>
                                        <td>
                                            <div class="fw-bold text-dark mb-1 student-name"><?= htmlspecialchars($order['student_name']) ?></div>
                                            <div class="small text-muted student-email"><?= htmlspecialchars($order['student_email']) ?></div>
                                        </td>
                                        <td class="text-truncate" style="max-width: 250px;">
                                            <span class="badge bg-light text-dark border course-name"><?= htmlspecialchars($order['course_name']) ?></span>
                                        </td>
                                        <td class="text-center">
                                            <?php if($order['payment_status'] === 'success'): ?>
                                                <span class="badge bg-success rounded-pill fw-bold"><i class="fas fa-check-circle me-1"></i> Paid & Provisioned</span>
                                            <?php elseif($order['payment_status'] === 'failed'): ?>
                                                <span class="badge bg-danger rounded-pill"><i class="fas fa-times me-1"></i> Failed Validation</span>
                                            <?php else: ?>
                                                <span class="badge bg-warning text-dark rounded-pill"><i class="fas fa-clock ps-1 opacity-50"></i> Init/Pending</span>
                                            <?php endif; ?>
                                        </td>
                                        <td class="text-end fw-bold text-dark pe-4 fs-6">
                                            ₹<?= number_format($order['amount'], 2) ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="5" class="text-center py-5 text-muted">
                                            <i class="fas fa-money-bill-wave fa-2x mb-2 opacity-50"></i>
                                            <p class="mb-0">No checkout sessions recorded yet.</p>
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/7.1.0/mdb.umd.min.js"></script>
<script>
    // Simple table search filter
    document.getElementById('searchInput').addEventListener('keyup', function() {
        let text = this.value.toLowerCase();
        let rows = document.querySelectorAll('.order-row');
        rows.forEach(function(row) {
            let id = row.querySelector('.order-id').textContent.toLowerCase();
            let name = row.querySelector('.student-name').textContent.toLowerCase();
            let course = row.querySelector('.course-name').textContent.toLowerCase();
            if(id.indexOf(text) > -1 || name.indexOf(text) > -1 || course.indexOf(text) > -1) {
                row.style.display = '';
            } else {
                row.style.display = 'none';
            }
        });
    });
</script>
</body>
</html>
