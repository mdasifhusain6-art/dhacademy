<?php
require_once 'config/database.php';
$page_title = "Home | DH ACADEMY";
$page_description = "Start your learning journey with DH ACADEMY. High-quality courses for your career growth.";
include 'includes/header.php';

// Fetch Top 6 Popular Courses (active ones)
$stmt = $pdo->query("SELECT * FROM courses WHERE is_active = 'yes' ORDER BY id DESC LIMIT 6");
$popular_courses = $stmt->fetchAll();

// Fetch total stats for trust signals
$total_students = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$total_courses = $pdo->query("SELECT COUNT(*) FROM courses WHERE is_active = 'yes'")->fetchColumn();
?>

<!-- Hero Section -->
<section class="hero-section text-white d-flex align-items-center position-relative overflow-hidden section-padding" style="background: linear-gradient(135deg, var(--primary-color) 0%, var(--primary-light) 100%); min-height: 80vh;">
  <!-- Abstract glass circles -->
  <div class="position-absolute rounded-circle bg-white opacity-10 blur-5" style="width: 500px; height: 500px; top: -100px; right: -150px; filter: blur(40px);"></div>
  <div class="position-absolute rounded-circle bg-warning opacity-10" style="width: 300px; height: 300px; bottom: 10%; left: -50px; filter: blur(60px);"></div>
  
  <div class="container position-relative z-1">
    <div class="row align-items-center g-5">
      <div class="col-lg-6 mb-5 mb-lg-0 pe-lg-5">
        <span class="badge glass-effect text-light mb-4 px-3 py-2 rounded-pill fw-bold" style="font-size: 0.9rem;"><i class="fas fa-star text-warning me-1"></i> #1 Learning Platform in India</span>
        <h1 class="display-3 fw-bolder mb-4" style="line-height: 1.1;">Master Skills That<br><span class="text-warning">Drive Careers.</span></h1>
        <p class="lead mb-5 opacity-90 fw-light" style="font-size: 1.25rem;">Join DH ACADEMY today. Access top-tier technical and non-technical courses designed by industry experts with lifetime access and dedicated support.</p>
        <div class="d-flex flex-column flex-sm-row gap-3">
          <a href="courses.php" class="btn btn-action btn-lg btn-rounded px-5 py-3 shadow-md">Explore Courses</a>
          <a href="about.php" class="btn btn-outline-light btn-lg btn-rounded px-5 py-3 shadow-sm border-2">Learn More</a>
        </div>
      </div>
      <div class="col-lg-6 text-center position-relative d-none d-lg-block">
          <div class="position-relative d-inline-block">
              <img src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" alt="Students Learning" class="img-fluid rounded-6 shadow-lg position-relative" style="border: 6px solid rgba(255,255,255,0.15); object-fit: cover; height: 550px; width: 100%;">
              
              <!-- Floating Stats Badge -->
              <div class="position-absolute bottom-0 start-0 glass-effect text-dark p-3 rounded-4 shadow-lg mb-5 ms-n4 d-flex align-items-center animation-float border-0" style="z-index: 2; transform: translateX(-20px);">
                  <div class="bg-primary-custom text-white rounded-circle d-flex align-items-center justify-content-center me-3 shadow-sm" style="width: 55px; height: 55px;">
                      <i class="fas fa-users fs-4"></i>
                  </div>
                  <div class="text-start pe-3">
                      <h3 class="fw-bold mb-0 text-primary-custom"><?= number_format(max($total_students, 500)) ?>+</h3>
                      <p class="small text-muted mb-0 fw-bold text-uppercase letter-spacing-1" style="font-size: 0.75rem;">Active Students</p>
                  </div>
              </div>
          </div>
      </div>
    </div>
  </div>
  <!-- Wave SVG Bottom -->
  <div class="position-absolute bottom-0 w-100" style="line-height: 0;">
    <svg viewBox="0 0 1440 120" fill="none" xmlns="http://www.w3.org/2000/svg" preserveAspectRatio="none" style="width: 100%; height: auto; min-height: 60px; max-height: 8vw;">
      <path d="M0,64L80,69.3C160,75,320,85,480,80C640,75,800,53,960,48C1120,43,1280,53,1360,58.7L1440,64L1440,120L1360,120C1280,120,1120,120,960,120C800,120,640,120,480,120C320,120,160,120,80,120L0,120Z" fill="var(--bg-card)"/>
    </svg>
  </div>
</section>

<!-- Stats Bar -->
<section class="py-5 bg-white border-bottom border-light">
    <div class="container">
        <div class="row text-center g-4">
            <div class="col-md-4">
                <h2 class="display-5 fw-bold text-primary-custom mb-2"><?= $total_courses ?>+</h2>
                <p class="text-uppercase fw-bold text-muted letter-spacing-1">Expert Courses</p>
            </div>
            <div class="col-md-4 border-end border-start">
                <h2 class="display-5 fw-bold text-warning mb-2">Lifetime</h2>
                <p class="text-uppercase fw-bold text-muted letter-spacing-1">Secure Access</p>
            </div>
            <div class="col-md-4">
                <h2 class="display-5 fw-bold text-success mb-2">100%</h2>
                <p class="text-uppercase fw-bold text-muted letter-spacing-1">Verified Certificates</p>
            </div>
        </div>
    </div>
</section>

<!-- Categories Section -->
<section class="py-5 bg-light">
  <div class="container py-4">
    <div class="text-center mb-5">
      <h6 class="text-warning fw-bold text-uppercase letter-spacing-1">Top Categories</h6>
      <h2 class="fw-bold">Explore Our Programs</h2>
    </div>
    
    <div class="row g-4 justify-content-center">
      <!-- Technical -->
      <div class="col-6 col-md-4 col-lg-3">
        <a href="courses.php?category=Technical" class="text-decoration-none">
          <div class="card h-100 border-0 shadow-sm hover-lift rounded-5 text-center p-4">
            <div class="icon-box bg-primary-custom text-white rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 70px; height: 70px;">
              <i class="fas fa-laptop-code fs-3"></i>
            </div>
            <h5 class="fw-bold text-dark mb-1">Technical</h5>
            <p class="text-muted small mb-0">Coding, App Dev, IT</p>
          </div>
        </a>
      </div>
      <!-- Non-Technical -->
      <div class="col-6 col-md-4 col-lg-3">
        <a href="courses.php?category=Non-Technical" class="text-decoration-none">
          <div class="card h-100 border-0 shadow-sm hover-lift rounded-5 text-center p-4">
            <div class="icon-box bg-warning text-dark rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 70px; height: 70px;">
              <i class="fas fa-chalkboard-teacher fs-3"></i>
            </div>
            <h5 class="fw-bold text-dark mb-1">Teaching</h5>
            <p class="text-muted small mb-0">NTT, Education</p>
          </div>
        </a>
      </div>
      <!-- Finance -->
      <div class="col-6 col-md-4 col-lg-3">
        <a href="courses.php?category=Accounting" class="text-decoration-none">
          <div class="card h-100 border-0 shadow-sm hover-lift rounded-5 text-center p-4">
            <div class="icon-box bg-success text-white rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 70px; height: 70px;">
              <i class="fas fa-file-invoice-dollar fs-3"></i>
            </div>
            <h5 class="fw-bold text-dark mb-1">Accounting</h5>
            <p class="text-muted small mb-0">Tally, Finance, Tax</p>
          </div>
        </a>
      </div>
      <!-- Marketing -->
      <div class="col-6 col-md-4 col-lg-3">
        <a href="courses.php?category=Marketing" class="text-decoration-none">
          <div class="card h-100 border-0 shadow-sm hover-lift rounded-5 text-center p-4">
            <div class="icon-box bg-info text-white rounded-circle mx-auto mb-3 d-flex align-items-center justify-content-center" style="width: 70px; height: 70px;">
              <i class="fas fa-bullhorn fs-3"></i>
            </div>
            <h5 class="fw-bold text-dark mb-1">Marketing</h5>
            <p class="text-muted small mb-0">SEO, Social Media</p>
          </div>
        </a>
      </div>
    </div>
  </div>
</section>

<!-- Popular Courses -->
<section class="py-5 bg-white">
  <div class="container py-5">
    <div class="d-flex justify-content-between align-items-end mb-5">
      <div>
        <h6 class="text-warning fw-bold text-uppercase letter-spacing-1">Trending</h6>
        <h2 class="fw-bold mb-0">Most Popular Courses</h2>
      </div>
      <a href="courses.php" class="btn btn-outline-primary btn-rounded d-none d-md-inline-block">View All</a>
    </div>

    <div class="row g-4">
      <?php foreach($popular_courses as $course): 
          // Check offer validity
          $is_offer_active = ($course['offer_active'] === 'yes' && (!empty($course['offer_end_date']) && strtotime($course['offer_end_date']) > time()));
          $display_price = $course['course_price'];
      ?>
      <div class="col-md-6 col-lg-4">
        <div class="card course-card h-100 rounded-6 shadow-sm border-0 hover-lift">
          <div class="position-relative img-wrapper">
              <img src="<?= htmlspecialchars($course['course_image']) ?: 'https://images.unsplash.com/photo-1547658719-da2b51169166?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80' ?>" class="card-img-top" alt="<?= htmlspecialchars($course['seo_title'] ?? $course['course_name']) ?>" loading="lazy" />
              <!-- overlay gradient -->
              <div class="position-absolute top-0 start-0 w-100 h-100" style="background: linear-gradient(to bottom, rgba(0,0,0,0.1), transparent 30%);"></div>
              <!-- Badges -->
              <div class="position-absolute top-0 start-0 m-3 d-flex flex-column gap-2">
                  <span class="badge bg-primary text-white px-3 py-2 rounded-pill shadow-sm glass-effect" style="border:none;"><i class="fas fa-tag me-1 text-white-50"></i> <?= htmlspecialchars($course['course_category']) ?></span>
                  <?php if($is_offer_active && !empty($course['offer_label'])): ?>
                    <span class="badge bg-danger px-3 py-2 rounded-pill shadow-md animate-pulse border-0"><i class="fas fa-fire me-1"></i> <?= htmlspecialchars($course['offer_label']) ?></span>
                  <?php endif; ?>
              </div>
          </div>
          <div class="card-body d-flex flex-column p-4">
            <h5 class="card-title fw-bold text-truncate-2 mb-3"><a href="course-details.php?id=<?= $course['id'] ?>" class="text-dark stretched-link"><?= htmlspecialchars($course['course_name']) ?></a></h5>
            
            <p class="text-muted small mb-4" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden;"><?= htmlspecialchars($course['short_description']) ?></p>

            <div class="d-flex justify-content-between align-items-center mb-4 text-muted small fw-medium">
              <span class="bg-light px-2 py-1 rounded"><i class="far fa-clock text-primary-custom me-1"></i> <?= htmlspecialchars($course['course_duration']) ?></span>
              <span class="bg-light px-2 py-1 rounded"><i class="fas fa-signal text-warning me-1"></i> <?= htmlspecialchars($course['course_level']) ?></span>
            </div>

            <div class="mt-auto pt-3 border-top border-light d-flex justify-content-between align-items-center position-relative z-1">
              <div>
                  <?php if($is_offer_active && !empty($course['original_price'])): ?>
                      <span class="text-muted text-decoration-line-through small fw-bold d-block">₹<?= number_format($course['original_price'], 2) ?></span>
                  <?php endif; ?>
                  <span class="fs-4 fw-bolder text-success">₹<?= number_format($display_price, 2) ?></span>
              </div>
              <span class="btn btn-action btn-sm btn-rounded px-3 py-2 shadow-sm fw-bold">View Details</span>
            </div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
    
    <div class="text-center mt-5 d-md-none">
        <a href="courses.php" class="btn btn-outline-primary btn-rounded w-100">View All Courses</a>
    </div>
  </div>
</section>

<!-- Call to Action -->
<section class="py-5 CTA-section text-center text-white" style="background: linear-gradient(135deg, #FF6B00 0%, #e65c00 100%); position: relative; overflow: hidden;">
    <div class="position-absolute rounded-circle bg-white opacity-10" style="width: 300px; height: 300px; top: -100px; right: -50px;"></div>
    <div class="position-absolute rounded-circle bg-white opacity-10" style="width: 200px; height: 200px; bottom: -80px; left: -50px;"></div>
    
    <div class="container py-5 position-relative z-1">
        <h2 class="display-5 fw-bold mb-4">Ready to Start Your Journey?</h2>
        <p class="lead mb-5 opacity-90 max-width-600 mx-auto">Join thousands of successful students who have transformed their careers with DH ACADEMY's expert-led courses.</p>
        <a href="register.php" class="btn btn-dark btn-lg btn-rounded px-5 shadow-4-strong me-3">Create Free Account</a>
        <a href="courses.php" class="btn btn-outline-light btn-lg btn-rounded px-5 mt-3 mt-md-0">Browse Catalog</a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
