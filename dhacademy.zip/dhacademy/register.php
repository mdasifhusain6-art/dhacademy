<?php
session_start();
require_once 'config/database.php';

if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: admin/dashboard.php");
    } else {
        header("Location: dashboard/index.php");
    }
    exit;
}

$error = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // V2.0 Validation Rules
    if (empty($name) || empty($email) || empty($password)) {
        $error = "All required fields must be filled.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } elseif (!empty($phone) && !preg_match("/^[0-9]{10}$/", $phone)) {
        $error = "Phone number must be exactly 10 digits.";
    } else {
        // Uniqueness check (double check despite AJAX)
        $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $error = "Email is already registered.";
        } else {
            // Success
            $hashed_password = password_hash($password, PASSWORD_BCRYPT);
            
            $stmt = $pdo->prepare("INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, 'student')");
            if ($stmt->execute([$name, $email, $phone, $hashed_password])) {
                
                // Auto-login after registration
                $_SESSION['user_id'] = $pdo->lastInsertId();
                $_SESSION['name'] = $name;
                $_SESSION['email'] = $email;
                $_SESSION['role'] = 'student';
                
                header("Location: dashboard/index.php?msg=welcome");
                exit;
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}

$page_title = "Register | DH ACADEMY";
include 'includes/header.php';
?>

<div class="container py-5 my-5">
  <div class="row justify-content-center">
    <div class="col-md-7 col-lg-6">
      <div class="card shadow-4-strong rounded-6 border-0">
        <div class="card-body p-4 p-md-5">
          
          <div class="text-center mb-4">
            <h3 class="fw-bold">Create an Account</h3>
            <p class="text-muted">Start learning with DH ACADEMY today.</p>
          </div>

          <?php if(!empty($error)): ?>
            <div class="alert alert-danger rounded-4 py-2 small fw-bold"><i class="fas fa-exclamation-circle me-1"></i> <?= htmlspecialchars($error) ?></div>
          <?php endif; ?>

          <form action="register.php" method="POST" id="registerForm">
            
            <div class="form-outline mb-4" data-mdb-input-init>
              <input type="text" id="name" name="name" class="form-control form-control-lg" required />
              <label class="form-label" for="name">Full Name *</label>
            </div>

            <div class="form-outline mb-4" data-mdb-input-init>
              <input type="email" id="email" name="email" class="form-control form-control-lg" required />
              <label class="form-label" for="email">Email address *</label>
              <div id="emailFeedback" class="form-text small mt-1 fw-bold"></div>
            </div>

            <div class="form-outline mb-4" data-mdb-input-init>
              <input type="tel" id="phone" name="phone" class="form-control form-control-lg" pattern="[0-9]{10}" title="10 digit Indian mobile number" />
              <label class="form-label" for="phone">WhatsApp Phone Number (Optional)</label>
            </div>

            <div class="row">
              <div class="col-md-6 mb-4">
                <div class="form-outline" data-mdb-input-init>
                  <input type="password" id="password" name="password" class="form-control form-control-lg" required minlength="8" />
                  <label class="form-label" for="password">Password *</label>
                </div>
              </div>
              
              <div class="col-md-6 mb-4">
                <div class="form-outline" data-mdb-input-init>
                  <input type="password" id="confirm_password" name="confirm_password" class="form-control form-control-lg" required minlength="8" />
                  <label class="form-label" for="confirm_password">Confirm Password *</label>
                </div>
              </div>
            </div>

             <div class="progress mb-4" style="height: 5px;" id="pwdStrengthCon" style="display:none;">
                <div class="progress-bar" id="pwdStrength" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
            </div>

            <button type="submit" id="submitBtn" class="btn btn-action btn-lg btn-block btn-rounded mb-4 shadow-1-strong hover-lift">Sign Up Now</button>

            <div class="text-center text-muted small">
              <p>Already have an account? <a href="login.php" class="text-primary-custom text-decoration-none fw-bold">Login here</a></p>
            </div>
          </form>

        </div>
      </div>
    </div>
  </div>
</div>

<?php include 'includes/footer.php'; ?>

<!-- Client-side Validation JS -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    
    // AJAX Email Check
    const emailInput = document.getElementById('email');
    const emailFeedback = document.getElementById('emailFeedback');
    const submitBtn = document.getElementById('submitBtn');
    
    let debounceTimer;
    
    emailInput.addEventListener('input', function() {
        clearTimeout(debounceTimer);
        const email = this.value.trim();
        emailFeedback.className = 'form-text small mt-1 fw-bold';
        
        if (email.length > 5 && email.includes('@')) {
            debounceTimer = setTimeout(() => {
                fetch('api/check-email.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                    body: 'email=' + encodeURIComponent(email)
                })
                .then(res => res.json())
                .then(data => {
                    emailFeedback.textContent = data.message;
                    if(data.status === 'exists') {
                        emailFeedback.classList.add('text-danger');
                        submitBtn.disabled = true;
                    } else if (data.status === 'available') {
                        emailFeedback.classList.add('text-success');
                        submitBtn.disabled = false;
                    }
                })
                .catch(err => console.error(err));
            }, 500);
        } else {
             emailFeedback.textContent = '';
             submitBtn.disabled = false;
        }
    });

    // Password Strength
    const pwdInput = document.getElementById('password');
    const pwdBar = document.getElementById('pwdStrength');
    
    pwdInput.addEventListener('input', function() {
        const val = this.value;
        let strength = 0;
        if(val.length >= 8) strength += 25;
        if(val.match(/[A-Z]/)) strength += 25;
        if(val.match(/[0-9]/)) strength += 25;
        if(val.match(/[^a-zA-Z0-9]/)) strength += 25;
        
        pwdBar.style.width = strength + '%';
        if(strength <= 25) { pwdBar.className = 'progress-bar bg-danger'; }
        else if(strength <= 50) { pwdBar.className = 'progress-bar bg-warning'; }
        else if(strength <= 75) { pwdBar.className = 'progress-bar bg-info'; }
        else { pwdBar.className = 'progress-bar bg-success'; }
    });
});
</script>
