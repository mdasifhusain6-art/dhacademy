<?php
session_start();
require_once '../config/database.php';
require_once '../config/razorpay.php';

// Disable error display
ini_set('display_errors', 0);
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $course_id = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
    // Note: Never trust front-end amount. Fetch from DB again, but frontend sends it for reference sometimes.
    
    $razorpay_order_id = isset($_POST['razorpay_order_id']) ? $_POST['razorpay_order_id'] : '';
    $razorpay_payment_id = isset($_POST['razorpay_payment_id']) ? $_POST['razorpay_payment_id'] : '';
    $razorpay_signature = isset($_POST['razorpay_signature']) ? $_POST['razorpay_signature'] : '';
    
    $student_name = isset($_POST['student_name']) ? trim($_POST['student_name']) : '';
    $student_email = isset($_POST['student_email']) ? trim($_POST['student_email']) : '';
    $student_password = isset($_POST['student_password']) ? $_POST['student_password'] : '';

    if (empty($razorpay_order_id) || empty($razorpay_payment_id) || empty($razorpay_signature)) {
        echo json_encode(['status' => 'error', 'message' => 'Missing payment parameters']);
        exit;
    }

    // --- 1. VERIFY SIGNATURE (HMAC SHA256) ---
    $generated_signature = hash_hmac('sha256', $razorpay_order_id . "|" . $razorpay_payment_id, RAZORPAY_KEY_SECRET);
    
    if (hash_equals($generated_signature, $razorpay_signature)) {
        
        // Ensure Course is valid and fetch exact DB price
        $stmt_c = $pdo->prepare("SELECT course_price FROM courses WHERE id = ?");
        $stmt_c->execute([$course_id]);
        $course = $stmt_c->fetch();
        
        if(!$course) {
            echo json_encode(['status' => 'error', 'message' => 'Invalid Course Details']);
            exit;
        }
        
        $db_amount = $course['course_price'];
        $user_id = 0;

        // --- 2. AUTHENTICATION / PROVISIONING ---
        if (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
        } else {
            if(empty($student_email) || empty($student_name)) {
                echo json_encode(['status' => 'error', 'message' => 'Email and Name required for Guest Checkout']);
                exit;
            }
            
            // Check if email already exists
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$student_email]);
            $existing_user = $stmt->fetch();

            if ($existing_user) {
                // DO NOT log them in automatically to prevent account takeover via spoofed email request.
                $user_id = $existing_user['id'];
            } else {
                // Auto create account
                if(empty($student_password)) {
                    $student_password = 'DH_' . rand(1000, 9999); // Fallback Temp Password
                }
                
                $hashed_password = password_hash($student_password, PASSWORD_BCRYPT);
                
                $stmt = $pdo->prepare("INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, 'student')");
                $stmt->execute([$student_name, $student_email, $hashed_password]);
                $user_id = $pdo->lastInsertId();
                
                // Log the newly created user in securely
                $_SESSION['user_id'] = $user_id;
                $_SESSION['name'] = $student_name;
                $_SESSION['email'] = $student_email;
                $_SESSION['role'] = 'student';
            }
        }

        // --- 3. PREVENT DUPLICATE ORDERS ---
        $check_order = $pdo->prepare("SELECT id FROM orders WHERE razorpay_order_id = ? OR razorpay_payment_id = ?");
        $check_order->execute([$razorpay_order_id, $razorpay_payment_id]);
        
        if($check_order->fetch()) {
            echo json_encode(['status' => 'success', 'redirect' => 'dashboard/my-courses.php', 'message' => 'Order already processed']);
            exit;
        }

        // --- 4. RECORD ORDER ---
        $stmt = $pdo->prepare("INSERT INTO orders (user_id, course_id, razorpay_order_id, razorpay_payment_id, amount, payment_status) VALUES (?, ?, ?, ?, ?, 'success')");
        $stmt->execute([$user_id, $course_id, $razorpay_order_id, $razorpay_payment_id, $db_amount]);

        echo json_encode(['status' => 'success', 'redirect' => 'dashboard/my-courses.php']);
        exit;

    } else {
        echo json_encode(['status' => 'error', 'message' => 'Signature Verification Failed Security Check']);
        exit;
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Access']);
}
?>
