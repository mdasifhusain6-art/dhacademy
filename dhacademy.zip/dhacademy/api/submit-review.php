<?php
require_once '../includes/auth-check.php';
require_once '../config/database.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $course_id = isset($_POST['course_id']) ? (int)$_POST['course_id'] : 0;
    $rating = isset($_POST['rating']) ? (int)$_POST['rating'] : 0;
    $title = isset($_POST['title']) ? trim($_POST['title']) : '';
    $review_text = isset($_POST['review_text']) ? trim($_POST['review_text']) : '';

    if ($course_id <= 0 || $rating < 1 || $rating > 5) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid input data.']);
        exit;
    }

    // Verify ownership
    $check_stmt = $pdo->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND payment_status = 'success'");
    $check_stmt->execute([$user_id, $course_id]);
    if (!$check_stmt->fetch()) {
        echo json_encode(['status' => 'error', 'message' => 'You must purchase this course to review it.']);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO reviews (user_id, course_id, rating, title, review_text) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE rating = ?, title = ?, review_text = ?");
        $stmt->execute([$user_id, $course_id, $rating, $title, $review_text, $rating, $title, $review_text]);
        echo json_encode(['status' => 'success', 'message' => 'Review submitted successfully.']);
    } catch (PDOException $e) {
        echo json_encode(['status' => 'error', 'message' => 'Database error occurred.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method.']);
}
?>
