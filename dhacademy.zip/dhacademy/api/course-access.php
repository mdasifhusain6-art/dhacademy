<?php
require_once '../includes/auth-check.php';
require_once '../config/database.php';

$user_id = $_SESSION['user_id'];

if (!isset($_GET['course_id']) || !is_numeric($_GET['course_id'])) {
    die("Invalid request");
}

$course_id = (int)$_GET['course_id'];

// Verify user actually owns the course
$stmt = $pdo->prepare("SELECT id FROM orders WHERE user_id = ? AND course_id = ? AND payment_status = 'success'");
$stmt->execute([$user_id, $course_id]);

if (!$stmt->fetch()) {
    die("Unauthorized access to course materials.");
}

// Fetch the link
$link_stmt = $pdo->prepare("SELECT google_drive_link FROM courses WHERE id = ?");
$link_stmt->execute([$course_id]);
$course = $link_stmt->fetch();

if ($course && !empty($course['google_drive_link'])) {
    // In a highly advanced setup, this could use Google Drive API to generate a temporary signed URL.
    // For this PRD scope, we redirect to the view-only folder link stored in DB.
    header("Location: " . $course['google_drive_link']);
    exit;
} else {
    die("Course materials are currently unavailable. Please contact support.");
}
?>
