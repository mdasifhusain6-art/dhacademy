<?php
session_start();
require_once '../config/database.php';
require_once '../config/razorpay.php';

// Disable error display to prevent malformed JSON
ini_set('display_errors', 0);
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['course_id'])) {
    
    $course_id = (int)$_POST['course_id'];
    
    // Verify course exists and is active
    $stmt = $pdo->prepare("SELECT id, course_name, course_price FROM courses WHERE id = ? AND is_active = 'yes'");
    $stmt->execute([$course_id]);
    $course = $stmt->fetch();

    if (!$course) {
        echo json_encode(['status' => 'error', 'message' => 'Course block unavailable or inactive.']);
        exit;
    }
    
    // Calculate final amount in paise for Razorpay
    $amountInPaise = round((float)$course['course_price'] * 100);

    // Call Razorpay API to generate order_id securely
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'https://api.razorpay.com/v1/orders');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode([
        'amount' => $amountInPaise,
        'currency' => 'INR',
        'receipt' => 'dh_rcpt_' . time() . '_' . $user_id
    ]));
    curl_setopt($ch, CURLOPT_USERPWD, RAZORPAY_KEY_ID . ':' . RAZORPAY_KEY_SECRET);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code === 200) {
        $razorpay_order = json_decode($response, true);
        
        echo json_encode([
            'status' => 'success',
            'order_id' => $razorpay_order['id'],
            'amount' => $amountInPaise,
            'amount_raw' => $course['course_price'],
            'course_name' => $course['course_name'],
            'key' => RAZORPAY_KEY_ID,
            // Pass user details if logged in for prefill
            'prefill_name' => isset($_SESSION['name']) ? $_SESSION['name'] : '',
            'prefill_email' => isset($_SESSION['email']) ? $_SESSION['email'] : '',
            'prefill_phone' => '' // Can add phone if stored in session
        ]);
        
    } else {
        // Log error secretly, return generic error
        error_log("Razorpay API Error: " . $response);
        echo json_encode(['status' => 'error', 'message' => 'Failed to initialize payment gateway.']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid Request Structure']);
}
?>
