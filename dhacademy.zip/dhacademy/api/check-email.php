<?php
require_once '../config/database.php';

header('Content-Type: application/json');

if (isset($_POST['email'])) {
    $email = trim($_POST['email']);
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['status' => 'invalid', 'message' => 'Invalid email format']);
        exit;
    }
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user) {
        echo json_encode(['status' => 'exists', 'message' => 'Email is already taken']);
    } else {
        echo json_encode(['status' => 'available', 'message' => 'Email is available']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No email provided']);
}
?>
